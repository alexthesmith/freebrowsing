// background/header-spoofer.js — GeoShift v2.0
// HTTP Header spoofing با declarativeNetRequest
// پوشش: Accept-Language، Accept، Sec-CH-UA، User-Agent headers

export function buildHeaderRules(profile) {
  if (!profile) return [];

  const rules = [];
  let ruleId = 1;

  // ══════════════════════════════════════════════════
  // Accept-Language header
  // مثال: de-DE,de;q=0.9,en-GB;q=0.8,en;q=0.7
  // ══════════════════════════════════════════════════
  const acceptLang = profile.languages
    .map((lang, i) => i === 0 ? lang : `${lang};q=${(1 - i * 0.1).toFixed(1)}`)
    .join(',');

  rules.push({
    id: ruleId++,
    priority: 1,
    action: {
      type: "modifyHeaders",
      requestHeaders: [
        { header: "Accept-Language", operation: "set", value: acceptLang }
      ]
    },
    condition: {
      urlFilter: "*",
      resourceTypes: [
        "main_frame","sub_frame","stylesheet","script","image",
        "font","object","xmlhttprequest","ping","csp_report",
        "media","websocket","other"
      ]
    }
  });

  // ══════════════════════════════════════════════════
  // User-Agent header
  // ══════════════════════════════════════════════════
  rules.push({
    id: ruleId++,
    priority: 1,
    action: {
      type: "modifyHeaders",
      requestHeaders: [
        { header: "User-Agent", operation: "set", value: profile.userAgent }
      ]
    },
    condition: {
      urlFilter: "*",
      resourceTypes: ["main_frame","sub_frame","xmlhttprequest","other"]
    }
  });

  // ══════════════════════════════════════════════════
  // Sec-CH-UA headers (Client Hints)
  // این‌ها مهم‌ترین headerهای مدرن برای fingerprinting هستن
  // ══════════════════════════════════════════════════
  const secChUa = profile.uaBrands
    .map(b => `"${b.brand}";v="${b.version}"`)
    .join(', ');

  rules.push({
    id: ruleId++,
    priority: 1,
    action: {
      type: "modifyHeaders",
      requestHeaders: [
        { header: "Sec-CH-UA",          operation: "set", value: secChUa },
        { header: "Sec-CH-UA-Mobile",   operation: "set", value: "?0" },
        { header: "Sec-CH-UA-Platform", operation: "set", value: `"${profile.uaPlatform}"` }
      ]
    },
    condition: {
      urlFilter: "*",
      resourceTypes: ["main_frame","sub_frame","xmlhttprequest","other"]
    }
  });

  // ══════════════════════════════════════════════════
  // Accept header — استاندارد Chrome
  // ══════════════════════════════════════════════════
  rules.push({
    id: ruleId++,
    priority: 1,
    action: {
      type: "modifyHeaders",
      requestHeaders: [
        {
          header: "Accept",
          operation: "set",
          value: "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7"
        }
      ]
    },
    condition: {
      urlFilter: "*",
      resourceTypes: ["main_frame","sub_frame"]
    }
  });

  // ══════════════════════════════════════════════════
  // Accept-Encoding — استاندارد Chrome
  // ══════════════════════════════════════════════════
  rules.push({
    id: ruleId++,
    priority: 1,
    action: {
      type: "modifyHeaders",
      requestHeaders: [
        { header: "Accept-Encoding", operation: "set", value: "gzip, deflate, br, zstd" }
      ]
    },
    condition: {
      urlFilter: "*",
      resourceTypes: ["main_frame","sub_frame","xmlhttprequest","other"]
    }
  });

  // ══════════════════════════════════════════════════
  // حذف headerهایی که fingerprint رو لو میدن
  // ══════════════════════════════════════════════════
  rules.push({
    id: ruleId++,
    priority: 1,
    action: {
      type: "modifyHeaders",
      requestHeaders: [
        { header: "X-Forwarded-For",   operation: "remove" },
        { header: "X-Real-IP",         operation: "remove" },
        { header: "Via",               operation: "remove" },
        { header: "Forwarded",         operation: "remove" }
      ]
    },
    condition: {
      urlFilter: "*",
      resourceTypes: ["main_frame","sub_frame","xmlhttprequest","other"]
    }
  });

  return rules;
}
