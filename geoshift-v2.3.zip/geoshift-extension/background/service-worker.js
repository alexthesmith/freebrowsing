// background/service-worker.js — GeoShift v2.2

// ══════════════════════════════════════════════════
// COUNTRY PROFILES
// ══════════════════════════════════════════════════
const COUNTRY_PROFILES = {

  // ══════════════════════════════════════════════════
  // WESTERN EUROPE
  // ══════════════════════════════════════════════════

  "DE": {
    name:"Germany", flag:"🇩🇪", timezone:"Europe/Berlin", tzOffset:-120,
    languages:["de-DE","de","en-GB","en"], locale:"de-DE",
    platform:"Win32", vendor:"Google Inc.", productSub:"20030107",
    doNotTrack:null, hardwareConcurrency:8, deviceMemory:8, maxTouchPoints:0,
    userAgent:"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
    uaPlatform:"Windows", uaFullVersion:"124.0.6367.82",
    uaBrands:[{brand:"Chromium",version:"124"},{brand:"Google Chrome",version:"124"},{brand:"Not-A.Brand",version:"99"}],
    architecture:"x86", bitness:"64", platformVersion:"10.0.0",
    screen:{width:1920,height:1080,colorDepth:24,pixelRatio:1},
    webglVendor:"Intel Inc.", webglRenderer:"Intel(R) UHD Graphics 620",
    webglVendorBasic:"Intel", webglRendererBasic:"Intel(R) UHD Graphics 620",
    fonts:["Arial","Arial Black","Calibri","Cambria","Comic Sans MS","Courier New","Georgia","Impact","Segoe UI","Tahoma","Times New Roman","Trebuchet MS","Verdana","Helvetica","Palatino"],
    speechLang:"de-DE", connection:{type:"wifi",downlink:10,rtt:50}, battery:{charging:false,level:0.72}
  },

  "FR": {
    name:"France", flag:"🇫🇷", timezone:"Europe/Paris", tzOffset:-120,
    languages:["fr-FR","fr","en-GB","en"], locale:"fr-FR",
    platform:"Win32", vendor:"Google Inc.", productSub:"20030107",
    doNotTrack:null, hardwareConcurrency:8, deviceMemory:8, maxTouchPoints:0,
    userAgent:"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
    uaPlatform:"Windows", uaFullVersion:"124.0.6367.82",
    uaBrands:[{brand:"Chromium",version:"124"},{brand:"Google Chrome",version:"124"},{brand:"Not-A.Brand",version:"99"}],
    architecture:"x86", bitness:"64", platformVersion:"10.0.0",
    screen:{width:1920,height:1080,colorDepth:24,pixelRatio:1},
    webglVendor:"Intel Inc.", webglRenderer:"Intel(R) UHD Graphics 620",
    webglVendorBasic:"Intel", webglRendererBasic:"Intel(R) UHD Graphics 620",
    fonts:["Arial","Calibri","Cambria","Courier New","Georgia","Segoe UI","Tahoma","Times New Roman","Trebuchet MS","Verdana"],
    speechLang:"fr-FR", connection:{type:"wifi",downlink:12,rtt:15}, battery:{charging:false,level:0.55}
  },

  "GB": {
    name:"United Kingdom", flag:"🇬🇧", timezone:"Europe/London", tzOffset:-60,
    languages:["en-GB","en"], locale:"en-GB",
    platform:"Win32", vendor:"Google Inc.", productSub:"20030107",
    doNotTrack:null, hardwareConcurrency:8, deviceMemory:8, maxTouchPoints:0,
    userAgent:"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
    uaPlatform:"Windows", uaFullVersion:"124.0.6367.82",
    uaBrands:[{brand:"Chromium",version:"124"},{brand:"Google Chrome",version:"124"},{brand:"Not-A.Brand",version:"99"}],
    architecture:"x86", bitness:"64", platformVersion:"10.0.0",
    screen:{width:1920,height:1080,colorDepth:24,pixelRatio:1},
    webglVendor:"Intel Inc.", webglRenderer:"Intel(R) UHD Graphics 630",
    webglVendorBasic:"Intel", webglRendererBasic:"Intel(R) UHD Graphics 630",
    fonts:["Arial","Arial Black","Calibri","Cambria","Courier New","Georgia","Impact","Segoe UI","Tahoma","Times New Roman","Trebuchet MS","Verdana","Helvetica"],
    speechLang:"en-GB", connection:{type:"wifi",downlink:8,rtt:20}, battery:{charging:false,level:0.61}
  },

  "NL": {
    name:"Netherlands", flag:"🇳🇱", timezone:"Europe/Amsterdam", tzOffset:-120,
    languages:["nl-NL","nl","en-GB","en","de"], locale:"nl-NL",
    platform:"Win32", vendor:"Google Inc.", productSub:"20030107",
    doNotTrack:"1", hardwareConcurrency:8, deviceMemory:16, maxTouchPoints:0,
    userAgent:"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
    uaPlatform:"Windows", uaFullVersion:"124.0.6367.82",
    uaBrands:[{brand:"Chromium",version:"124"},{brand:"Google Chrome",version:"124"},{brand:"Not-A.Brand",version:"99"}],
    architecture:"x86", bitness:"64", platformVersion:"10.0.0",
    screen:{width:2560,height:1440,colorDepth:24,pixelRatio:1},
    webglVendor:"Intel Inc.", webglRenderer:"Intel(R) Iris(R) Xe Graphics",
    webglVendorBasic:"Intel", webglRendererBasic:"Intel(R) Iris(R) Xe Graphics",
    fonts:["Arial","Calibri","Cambria","Courier New","Georgia","Segoe UI","Tahoma","Times New Roman","Verdana"],
    speechLang:"nl-NL", connection:{type:"wifi",downlink:25,rtt:10}, battery:{charging:true,level:0.91}
  },

  "BE": {
    name:"Belgium", flag:"🇧🇪", timezone:"Europe/Brussels", tzOffset:-120,
    languages:["fr-BE","fr","nl-BE","nl","de","en"], locale:"fr-BE",
    platform:"Win32", vendor:"Google Inc.", productSub:"20030107",
    doNotTrack:null, hardwareConcurrency:8, deviceMemory:8, maxTouchPoints:0,
    userAgent:"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
    uaPlatform:"Windows", uaFullVersion:"124.0.6367.82",
    uaBrands:[{brand:"Chromium",version:"124"},{brand:"Google Chrome",version:"124"},{brand:"Not-A.Brand",version:"99"}],
    architecture:"x86", bitness:"64", platformVersion:"10.0.0",
    screen:{width:1920,height:1080,colorDepth:24,pixelRatio:1},
    webglVendor:"Intel Inc.", webglRenderer:"Intel(R) UHD Graphics 620",
    webglVendorBasic:"Intel", webglRendererBasic:"Intel(R) UHD Graphics 620",
    fonts:["Arial","Calibri","Cambria","Courier New","Georgia","Segoe UI","Tahoma","Times New Roman","Verdana"],
    speechLang:"fr-BE", connection:{type:"wifi",downlink:15,rtt:12}, battery:{charging:false,level:0.67}
  },

  "CH": {
    name:"Switzerland", flag:"🇨🇭", timezone:"Europe/Zurich", tzOffset:-120,
    languages:["de-CH","de","fr-CH","fr","it-CH","it","en"], locale:"de-CH",
    platform:"Win32", vendor:"Google Inc.", productSub:"20030107",
    doNotTrack:"1", hardwareConcurrency:8, deviceMemory:16, maxTouchPoints:0,
    userAgent:"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
    uaPlatform:"Windows", uaFullVersion:"124.0.6367.82",
    uaBrands:[{brand:"Chromium",version:"124"},{brand:"Google Chrome",version:"124"},{brand:"Not-A.Brand",version:"99"}],
    architecture:"x86", bitness:"64", platformVersion:"10.0.0",
    screen:{width:2560,height:1440,colorDepth:24,pixelRatio:2},
    webglVendor:"Intel Inc.", webglRenderer:"Intel(R) Iris(R) Xe Graphics",
    webglVendorBasic:"Intel", webglRendererBasic:"Intel(R) Iris(R) Xe Graphics",
    fonts:["Arial","Calibri","Cambria","Courier New","Georgia","Helvetica","Segoe UI","Tahoma","Times New Roman","Verdana"],
    speechLang:"de-CH", connection:{type:"wifi",downlink:50,rtt:5}, battery:{charging:true,level:0.88}
  },

  "AT": {
    name:"Austria", flag:"🇦🇹", timezone:"Europe/Vienna", tzOffset:-120,
    languages:["de-AT","de","en"], locale:"de-AT",
    platform:"Win32", vendor:"Google Inc.", productSub:"20030107",
    doNotTrack:null, hardwareConcurrency:8, deviceMemory:8, maxTouchPoints:0,
    userAgent:"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
    uaPlatform:"Windows", uaFullVersion:"124.0.6367.82",
    uaBrands:[{brand:"Chromium",version:"124"},{brand:"Google Chrome",version:"124"},{brand:"Not-A.Brand",version:"99"}],
    architecture:"x86", bitness:"64", platformVersion:"10.0.0",
    screen:{width:1920,height:1080,colorDepth:24,pixelRatio:1},
    webglVendor:"Intel Inc.", webglRenderer:"Intel(R) UHD Graphics 620",
    webglVendorBasic:"Intel", webglRendererBasic:"Intel(R) UHD Graphics 620",
    fonts:["Arial","Calibri","Cambria","Courier New","Georgia","Segoe UI","Tahoma","Times New Roman","Verdana"],
    speechLang:"de-AT", connection:{type:"wifi",downlink:10,rtt:20}, battery:{charging:false,level:0.70}
  },

  "ES": {
    name:"Spain", flag:"🇪🇸", timezone:"Europe/Madrid", tzOffset:-120,
    languages:["es-ES","es","ca","en"], locale:"es-ES",
    platform:"Win32", vendor:"Google Inc.", productSub:"20030107",
    doNotTrack:null, hardwareConcurrency:8, deviceMemory:8, maxTouchPoints:0,
    userAgent:"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
    uaPlatform:"Windows", uaFullVersion:"124.0.6367.82",
    uaBrands:[{brand:"Chromium",version:"124"},{brand:"Google Chrome",version:"124"},{brand:"Not-A.Brand",version:"99"}],
    architecture:"x86", bitness:"64", platformVersion:"10.0.0",
    screen:{width:1920,height:1080,colorDepth:24,pixelRatio:1},
    webglVendor:"Intel Inc.", webglRenderer:"Intel(R) UHD Graphics 620",
    webglVendorBasic:"Intel", webglRendererBasic:"Intel(R) UHD Graphics 620",
    fonts:["Arial","Calibri","Cambria","Courier New","Georgia","Segoe UI","Tahoma","Times New Roman","Verdana"],
    speechLang:"es-ES", connection:{type:"wifi",downlink:10,rtt:25}, battery:{charging:false,level:0.58}
  },

  "IT": {
    name:"Italy", flag:"🇮🇹", timezone:"Europe/Rome", tzOffset:-120,
    languages:["it-IT","it","en"], locale:"it-IT",
    platform:"Win32", vendor:"Google Inc.", productSub:"20030107",
    doNotTrack:null, hardwareConcurrency:8, deviceMemory:8, maxTouchPoints:0,
    userAgent:"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
    uaPlatform:"Windows", uaFullVersion:"124.0.6367.82",
    uaBrands:[{brand:"Chromium",version:"124"},{brand:"Google Chrome",version:"124"},{brand:"Not-A.Brand",version:"99"}],
    architecture:"x86", bitness:"64", platformVersion:"10.0.0",
    screen:{width:1920,height:1080,colorDepth:24,pixelRatio:1},
    webglVendor:"Intel Inc.", webglRenderer:"Intel(R) UHD Graphics 620",
    webglVendorBasic:"Intel", webglRendererBasic:"Intel(R) UHD Graphics 620",
    fonts:["Arial","Calibri","Cambria","Courier New","Georgia","Segoe UI","Tahoma","Times New Roman","Verdana"],
    speechLang:"it-IT", connection:{type:"wifi",downlink:8,rtt:30}, battery:{charging:false,level:0.63}
  },

  "PT": {
    name:"Portugal", flag:"🇵🇹", timezone:"Europe/Lisbon", tzOffset:0,
    languages:["pt-PT","pt","en"], locale:"pt-PT",
    platform:"Win32", vendor:"Google Inc.", productSub:"20030107",
    doNotTrack:null, hardwareConcurrency:8, deviceMemory:8, maxTouchPoints:0,
    userAgent:"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
    uaPlatform:"Windows", uaFullVersion:"124.0.6367.82",
    uaBrands:[{brand:"Chromium",version:"124"},{brand:"Google Chrome",version:"124"},{brand:"Not-A.Brand",version:"99"}],
    architecture:"x86", bitness:"64", platformVersion:"10.0.0",
    screen:{width:1920,height:1080,colorDepth:24,pixelRatio:1},
    webglVendor:"Intel Inc.", webglRenderer:"Intel(R) UHD Graphics 620",
    webglVendorBasic:"Intel", webglRendererBasic:"Intel(R) UHD Graphics 620",
    fonts:["Arial","Calibri","Courier New","Georgia","Segoe UI","Tahoma","Times New Roman","Verdana"],
    speechLang:"pt-PT", connection:{type:"wifi",downlink:8,rtt:35}, battery:{charging:false,level:0.60}
  },

  "LU": {
    name:"Luxembourg", flag:"🇱🇺", timezone:"Europe/Luxembourg", tzOffset:-120,
    languages:["fr-LU","fr","de-LU","de","lb","en"], locale:"fr-LU",
    platform:"Win32", vendor:"Google Inc.", productSub:"20030107",
    doNotTrack:null, hardwareConcurrency:8, deviceMemory:16, maxTouchPoints:0,
    userAgent:"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
    uaPlatform:"Windows", uaFullVersion:"124.0.6367.82",
    uaBrands:[{brand:"Chromium",version:"124"},{brand:"Google Chrome",version:"124"},{brand:"Not-A.Brand",version:"99"}],
    architecture:"x86", bitness:"64", platformVersion:"10.0.0",
    screen:{width:1920,height:1080,colorDepth:24,pixelRatio:1},
    webglVendor:"Intel Inc.", webglRenderer:"Intel(R) Iris(R) Xe Graphics",
    webglVendorBasic:"Intel", webglRendererBasic:"Intel(R) Iris(R) Xe Graphics",
    fonts:["Arial","Calibri","Courier New","Georgia","Segoe UI","Tahoma","Verdana"],
    speechLang:"fr-LU", connection:{type:"wifi",downlink:30,rtt:8}, battery:{charging:true,level:0.82}
  },

  "IE": {
    name:"Ireland", flag:"🇮🇪", timezone:"Europe/Dublin", tzOffset:-60,
    languages:["en-IE","en","ga"], locale:"en-IE",
    platform:"Win32", vendor:"Google Inc.", productSub:"20030107",
    doNotTrack:null, hardwareConcurrency:8, deviceMemory:8, maxTouchPoints:0,
    userAgent:"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
    uaPlatform:"Windows", uaFullVersion:"124.0.6367.82",
    uaBrands:[{brand:"Chromium",version:"124"},{brand:"Google Chrome",version:"124"},{brand:"Not-A.Brand",version:"99"}],
    architecture:"x86", bitness:"64", platformVersion:"10.0.0",
    screen:{width:1920,height:1080,colorDepth:24,pixelRatio:1},
    webglVendor:"Intel Inc.", webglRenderer:"Intel(R) UHD Graphics 630",
    webglVendorBasic:"Intel", webglRendererBasic:"Intel(R) UHD Graphics 630",
    fonts:["Arial","Calibri","Courier New","Georgia","Segoe UI","Tahoma","Times New Roman","Verdana"],
    speechLang:"en-IE", connection:{type:"wifi",downlink:10,rtt:22}, battery:{charging:false,level:0.75}
  },

  // ══════════════════════════════════════════════════
  // NORTHERN EUROPE
  // ══════════════════════════════════════════════════

  "SE": {
    name:"Sweden", flag:"🇸🇪", timezone:"Europe/Stockholm", tzOffset:-120,
    languages:["sv-SE","sv","en-GB","en"], locale:"sv-SE",
    platform:"Win32", vendor:"Google Inc.", productSub:"20030107",
    doNotTrack:"1", hardwareConcurrency:8, deviceMemory:8, maxTouchPoints:0,
    userAgent:"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
    uaPlatform:"Windows", uaFullVersion:"124.0.6367.82",
    uaBrands:[{brand:"Chromium",version:"124"},{brand:"Google Chrome",version:"124"},{brand:"Not-A.Brand",version:"99"}],
    architecture:"x86", bitness:"64", platformVersion:"10.0.0",
    screen:{width:1920,height:1080,colorDepth:24,pixelRatio:1},
    webglVendor:"Intel Inc.", webglRenderer:"Intel(R) UHD Graphics 620",
    webglVendorBasic:"Intel", webglRendererBasic:"Intel(R) UHD Graphics 620",
    fonts:["Arial","Calibri","Courier New","Georgia","Segoe UI","Tahoma","Verdana"],
    speechLang:"sv-SE", connection:{type:"wifi",downlink:20,rtt:8}, battery:{charging:false,level:0.78}
  },

  "NO": {
    name:"Norway", flag:"🇳🇴", timezone:"Europe/Oslo", tzOffset:-120,
    languages:["nb-NO","nb","nn-NO","nn","en"], locale:"nb-NO",
    platform:"Win32", vendor:"Google Inc.", productSub:"20030107",
    doNotTrack:"1", hardwareConcurrency:8, deviceMemory:8, maxTouchPoints:0,
    userAgent:"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
    uaPlatform:"Windows", uaFullVersion:"124.0.6367.82",
    uaBrands:[{brand:"Chromium",version:"124"},{brand:"Google Chrome",version:"124"},{brand:"Not-A.Brand",version:"99"}],
    architecture:"x86", bitness:"64", platformVersion:"10.0.0",
    screen:{width:2560,height:1440,colorDepth:24,pixelRatio:1},
    webglVendor:"Intel Inc.", webglRenderer:"Intel(R) UHD Graphics 620",
    webglVendorBasic:"Intel", webglRendererBasic:"Intel(R) UHD Graphics 620",
    fonts:["Arial","Calibri","Courier New","Georgia","Segoe UI","Tahoma","Verdana"],
    speechLang:"nb-NO", connection:{type:"wifi",downlink:25,rtt:6}, battery:{charging:true,level:0.92}
  },

  "DK": {
    name:"Denmark", flag:"🇩🇰", timezone:"Europe/Copenhagen", tzOffset:-120,
    languages:["da-DK","da","en-GB","en"], locale:"da-DK",
    platform:"Win32", vendor:"Google Inc.", productSub:"20030107",
    doNotTrack:"1", hardwareConcurrency:8, deviceMemory:8, maxTouchPoints:0,
    userAgent:"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
    uaPlatform:"Windows", uaFullVersion:"124.0.6367.82",
    uaBrands:[{brand:"Chromium",version:"124"},{brand:"Google Chrome",version:"124"},{brand:"Not-A.Brand",version:"99"}],
    architecture:"x86", bitness:"64", platformVersion:"10.0.0",
    screen:{width:1920,height:1080,colorDepth:24,pixelRatio:1},
    webglVendor:"Intel Inc.", webglRenderer:"Intel(R) UHD Graphics 620",
    webglVendorBasic:"Intel", webglRendererBasic:"Intel(R) UHD Graphics 620",
    fonts:["Arial","Calibri","Courier New","Georgia","Segoe UI","Tahoma","Verdana"],
    speechLang:"da-DK", connection:{type:"wifi",downlink:20,rtt:9}, battery:{charging:false,level:0.74}
  },

  "FI": {
    name:"Finland", flag:"🇫🇮", timezone:"Europe/Helsinki", tzOffset:-180,
    languages:["fi-FI","fi","sv-FI","sv","en"], locale:"fi-FI",
    platform:"Win32", vendor:"Google Inc.", productSub:"20030107",
    doNotTrack:"1", hardwareConcurrency:8, deviceMemory:8, maxTouchPoints:0,
    userAgent:"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
    uaPlatform:"Windows", uaFullVersion:"124.0.6367.82",
    uaBrands:[{brand:"Chromium",version:"124"},{brand:"Google Chrome",version:"124"},{brand:"Not-A.Brand",version:"99"}],
    architecture:"x86", bitness:"64", platformVersion:"10.0.0",
    screen:{width:1920,height:1080,colorDepth:24,pixelRatio:1},
    webglVendor:"Intel Inc.", webglRenderer:"Intel(R) UHD Graphics 620",
    webglVendorBasic:"Intel", webglRendererBasic:"Intel(R) UHD Graphics 620",
    fonts:["Arial","Calibri","Courier New","Georgia","Segoe UI","Tahoma","Verdana"],
    speechLang:"fi-FI", connection:{type:"wifi",downlink:20,rtt:7}, battery:{charging:false,level:0.81}
  },

  "IS": {
    name:"Iceland", flag:"🇮🇸", timezone:"Atlantic/Reykjavik", tzOffset:0,
    languages:["is-IS","is","en"], locale:"is-IS",
    platform:"Win32", vendor:"Google Inc.", productSub:"20030107",
    doNotTrack:"1", hardwareConcurrency:8, deviceMemory:8, maxTouchPoints:0,
    userAgent:"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
    uaPlatform:"Windows", uaFullVersion:"124.0.6367.82",
    uaBrands:[{brand:"Chromium",version:"124"},{brand:"Google Chrome",version:"124"},{brand:"Not-A.Brand",version:"99"}],
    architecture:"x86", bitness:"64", platformVersion:"10.0.0",
    screen:{width:1920,height:1080,colorDepth:24,pixelRatio:1},
    webglVendor:"Intel Inc.", webglRenderer:"Intel(R) UHD Graphics 620",
    webglVendorBasic:"Intel", webglRendererBasic:"Intel(R) UHD Graphics 620",
    fonts:["Arial","Calibri","Courier New","Georgia","Segoe UI","Tahoma","Verdana"],
    speechLang:"is-IS", connection:{type:"wifi",downlink:15,rtt:15}, battery:{charging:true,level:0.89}
  },

  // ══════════════════════════════════════════════════
  // EASTERN EUROPE
  // ══════════════════════════════════════════════════

  "PL": {
    name:"Poland", flag:"🇵🇱", timezone:"Europe/Warsaw", tzOffset:-120,
    languages:["pl-PL","pl","en"], locale:"pl-PL",
    platform:"Win32", vendor:"Google Inc.", productSub:"20030107",
    doNotTrack:null, hardwareConcurrency:8, deviceMemory:8, maxTouchPoints:0,
    userAgent:"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
    uaPlatform:"Windows", uaFullVersion:"124.0.6367.82",
    uaBrands:[{brand:"Chromium",version:"124"},{brand:"Google Chrome",version:"124"},{brand:"Not-A.Brand",version:"99"}],
    architecture:"x86", bitness:"64", platformVersion:"10.0.0",
    screen:{width:1920,height:1080,colorDepth:24,pixelRatio:1},
    webglVendor:"Intel Inc.", webglRenderer:"Intel(R) UHD Graphics 620",
    webglVendorBasic:"Intel", webglRendererBasic:"Intel(R) UHD Graphics 620",
    fonts:["Arial","Calibri","Cambria","Courier New","Georgia","Segoe UI","Tahoma","Times New Roman","Verdana"],
    speechLang:"pl-PL", connection:{type:"wifi",downlink:10,rtt:30}, battery:{charging:false,level:0.65}
  },

  "CZ": {
    name:"Czech Republic", flag:"🇨🇿", timezone:"Europe/Prague", tzOffset:-120,
    languages:["cs-CZ","cs","sk","en"], locale:"cs-CZ",
    platform:"Win32", vendor:"Google Inc.", productSub:"20030107",
    doNotTrack:null, hardwareConcurrency:8, deviceMemory:8, maxTouchPoints:0,
    userAgent:"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
    uaPlatform:"Windows", uaFullVersion:"124.0.6367.82",
    uaBrands:[{brand:"Chromium",version:"124"},{brand:"Google Chrome",version:"124"},{brand:"Not-A.Brand",version:"99"}],
    architecture:"x86", bitness:"64", platformVersion:"10.0.0",
    screen:{width:1920,height:1080,colorDepth:24,pixelRatio:1},
    webglVendor:"Intel Inc.", webglRenderer:"Intel(R) UHD Graphics 620",
    webglVendorBasic:"Intel", webglRendererBasic:"Intel(R) UHD Graphics 620",
    fonts:["Arial","Calibri","Cambria","Courier New","Georgia","Segoe UI","Tahoma","Times New Roman","Verdana"],
    speechLang:"cs-CZ", connection:{type:"wifi",downlink:10,rtt:25}, battery:{charging:false,level:0.68}
  },

  "SK": {
    name:"Slovakia", flag:"🇸🇰", timezone:"Europe/Bratislava", tzOffset:-120,
    languages:["sk-SK","sk","cs","en"], locale:"sk-SK",
    platform:"Win32", vendor:"Google Inc.", productSub:"20030107",
    doNotTrack:null, hardwareConcurrency:8, deviceMemory:8, maxTouchPoints:0,
    userAgent:"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
    uaPlatform:"Windows", uaFullVersion:"124.0.6367.82",
    uaBrands:[{brand:"Chromium",version:"124"},{brand:"Google Chrome",version:"124"},{brand:"Not-A.Brand",version:"99"}],
    architecture:"x86", bitness:"64", platformVersion:"10.0.0",
    screen:{width:1920,height:1080,colorDepth:24,pixelRatio:1},
    webglVendor:"Intel Inc.", webglRenderer:"Intel(R) UHD Graphics 620",
    webglVendorBasic:"Intel", webglRendererBasic:"Intel(R) UHD Graphics 620",
    fonts:["Arial","Calibri","Courier New","Georgia","Segoe UI","Tahoma","Verdana"],
    speechLang:"sk-SK", connection:{type:"wifi",downlink:10,rtt:28}, battery:{charging:false,level:0.64}
  },

  "HU": {
    name:"Hungary", flag:"🇭🇺", timezone:"Europe/Budapest", tzOffset:-120,
    languages:["hu-HU","hu","en"], locale:"hu-HU",
    platform:"Win32", vendor:"Google Inc.", productSub:"20030107",
    doNotTrack:null, hardwareConcurrency:8, deviceMemory:8, maxTouchPoints:0,
    userAgent:"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
    uaPlatform:"Windows", uaFullVersion:"124.0.6367.82",
    uaBrands:[{brand:"Chromium",version:"124"},{brand:"Google Chrome",version:"124"},{brand:"Not-A.Brand",version:"99"}],
    architecture:"x86", bitness:"64", platformVersion:"10.0.0",
    screen:{width:1920,height:1080,colorDepth:24,pixelRatio:1},
    webglVendor:"Intel Inc.", webglRenderer:"Intel(R) UHD Graphics 620",
    webglVendorBasic:"Intel", webglRendererBasic:"Intel(R) UHD Graphics 620",
    fonts:["Arial","Calibri","Courier New","Georgia","Segoe UI","Tahoma","Verdana"],
    speechLang:"hu-HU", connection:{type:"wifi",downlink:10,rtt:30}, battery:{charging:false,level:0.62}
  },

  "RO": {
    name:"Romania", flag:"🇷🇴", timezone:"Europe/Bucharest", tzOffset:-180,
    languages:["ro-RO","ro","en"], locale:"ro-RO",
    platform:"Win32", vendor:"Google Inc.", productSub:"20030107",
    doNotTrack:null, hardwareConcurrency:8, deviceMemory:8, maxTouchPoints:0,
    userAgent:"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
    uaPlatform:"Windows", uaFullVersion:"124.0.6367.82",
    uaBrands:[{brand:"Chromium",version:"124"},{brand:"Google Chrome",version:"124"},{brand:"Not-A.Brand",version:"99"}],
    architecture:"x86", bitness:"64", platformVersion:"10.0.0",
    screen:{width:1920,height:1080,colorDepth:24,pixelRatio:1},
    webglVendor:"Intel Inc.", webglRenderer:"Intel(R) UHD Graphics 620",
    webglVendorBasic:"Intel", webglRendererBasic:"Intel(R) UHD Graphics 620",
    fonts:["Arial","Calibri","Courier New","Georgia","Segoe UI","Tahoma","Verdana"],
    speechLang:"ro-RO", connection:{type:"wifi",downlink:15,rtt:25}, battery:{charging:false,level:0.59}
  },

  "BG": {
    name:"Bulgaria", flag:"🇧🇬", timezone:"Europe/Sofia", tzOffset:-180,
    languages:["bg-BG","bg","en"], locale:"bg-BG",
    platform:"Win32", vendor:"Google Inc.", productSub:"20030107",
    doNotTrack:null, hardwareConcurrency:8, deviceMemory:8, maxTouchPoints:0,
    userAgent:"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
    uaPlatform:"Windows", uaFullVersion:"124.0.6367.82",
    uaBrands:[{brand:"Chromium",version:"124"},{brand:"Google Chrome",version:"124"},{brand:"Not-A.Brand",version:"99"}],
    architecture:"x86", bitness:"64", platformVersion:"10.0.0",
    screen:{width:1920,height:1080,colorDepth:24,pixelRatio:1},
    webglVendor:"Intel Inc.", webglRenderer:"Intel(R) UHD Graphics 620",
    webglVendorBasic:"Intel", webglRendererBasic:"Intel(R) UHD Graphics 620",
    fonts:["Arial","Calibri","Courier New","Georgia","Segoe UI","Tahoma","Verdana"],
    speechLang:"bg-BG", connection:{type:"wifi",downlink:10,rtt:35}, battery:{charging:false,level:0.55}
  },

  "HR": {
    name:"Croatia", flag:"🇭🇷", timezone:"Europe/Zagreb", tzOffset:-120,
    languages:["hr-HR","hr","en"], locale:"hr-HR",
    platform:"Win32", vendor:"Google Inc.", productSub:"20030107",
    doNotTrack:null, hardwareConcurrency:8, deviceMemory:8, maxTouchPoints:0,
    userAgent:"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
    uaPlatform:"Windows", uaFullVersion:"124.0.6367.82",
    uaBrands:[{brand:"Chromium",version:"124"},{brand:"Google Chrome",version:"124"},{brand:"Not-A.Brand",version:"99"}],
    architecture:"x86", bitness:"64", platformVersion:"10.0.0",
    screen:{width:1920,height:1080,colorDepth:24,pixelRatio:1},
    webglVendor:"Intel Inc.", webglRenderer:"Intel(R) UHD Graphics 620",
    webglVendorBasic:"Intel", webglRendererBasic:"Intel(R) UHD Graphics 620",
    fonts:["Arial","Calibri","Courier New","Georgia","Segoe UI","Tahoma","Verdana"],
    speechLang:"hr-HR", connection:{type:"wifi",downlink:8,rtt:35}, battery:{charging:false,level:0.60}
  },

  "SI": {
    name:"Slovenia", flag:"🇸🇮", timezone:"Europe/Ljubljana", tzOffset:-120,
    languages:["sl-SI","sl","en","de"], locale:"sl-SI",
    platform:"Win32", vendor:"Google Inc.", productSub:"20030107",
    doNotTrack:null, hardwareConcurrency:8, deviceMemory:8, maxTouchPoints:0,
    userAgent:"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
    uaPlatform:"Windows", uaFullVersion:"124.0.6367.82",
    uaBrands:[{brand:"Chromium",version:"124"},{brand:"Google Chrome",version:"124"},{brand:"Not-A.Brand",version:"99"}],
    architecture:"x86", bitness:"64", platformVersion:"10.0.0",
    screen:{width:1920,height:1080,colorDepth:24,pixelRatio:1},
    webglVendor:"Intel Inc.", webglRenderer:"Intel(R) UHD Graphics 620",
    webglVendorBasic:"Intel", webglRendererBasic:"Intel(R) UHD Graphics 620",
    fonts:["Arial","Calibri","Courier New","Georgia","Segoe UI","Tahoma","Verdana"],
    speechLang:"sl-SI", connection:{type:"wifi",downlink:10,rtt:22}, battery:{charging:false,level:0.72}
  },

  "RS": {
    name:"Serbia", flag:"🇷🇸", timezone:"Europe/Belgrade", tzOffset:-120,
    languages:["sr-RS","sr","en"], locale:"sr-RS",
    platform:"Win32", vendor:"Google Inc.", productSub:"20030107",
    doNotTrack:null, hardwareConcurrency:8, deviceMemory:8, maxTouchPoints:0,
    userAgent:"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
    uaPlatform:"Windows", uaFullVersion:"124.0.6367.82",
    uaBrands:[{brand:"Chromium",version:"124"},{brand:"Google Chrome",version:"124"},{brand:"Not-A.Brand",version:"99"}],
    architecture:"x86", bitness:"64", platformVersion:"10.0.0",
    screen:{width:1920,height:1080,colorDepth:24,pixelRatio:1},
    webglVendor:"Intel Inc.", webglRenderer:"Intel(R) UHD Graphics 620",
    webglVendorBasic:"Intel", webglRendererBasic:"Intel(R) UHD Graphics 620",
    fonts:["Arial","Calibri","Courier New","Georgia","Segoe UI","Tahoma","Verdana"],
    speechLang:"sr-RS", connection:{type:"wifi",downlink:8,rtt:40}, battery:{charging:false,level:0.57}
  },

  "GR": {
    name:"Greece", flag:"🇬🇷", timezone:"Europe/Athens", tzOffset:-180,
    languages:["el-GR","el","en"], locale:"el-GR",
    platform:"Win32", vendor:"Google Inc.", productSub:"20030107",
    doNotTrack:null, hardwareConcurrency:8, deviceMemory:8, maxTouchPoints:0,
    userAgent:"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
    uaPlatform:"Windows", uaFullVersion:"124.0.6367.82",
    uaBrands:[{brand:"Chromium",version:"124"},{brand:"Google Chrome",version:"124"},{brand:"Not-A.Brand",version:"99"}],
    architecture:"x86", bitness:"64", platformVersion:"10.0.0",
    screen:{width:1920,height:1080,colorDepth:24,pixelRatio:1},
    webglVendor:"Intel Inc.", webglRenderer:"Intel(R) UHD Graphics 620",
    webglVendorBasic:"Intel", webglRendererBasic:"Intel(R) UHD Graphics 620",
    fonts:["Arial","Calibri","Courier New","Georgia","Segoe UI","Tahoma","Verdana"],
    speechLang:"el-GR", connection:{type:"wifi",downlink:8,rtt:40}, battery:{charging:false,level:0.53}
  },

  "UA": {
    name:"Ukraine", flag:"🇺🇦", timezone:"Europe/Kyiv", tzOffset:-180,
    languages:["uk-UA","uk","ru","en"], locale:"uk-UA",
    platform:"Win32", vendor:"Google Inc.", productSub:"20030107",
    doNotTrack:null, hardwareConcurrency:8, deviceMemory:8, maxTouchPoints:0,
    userAgent:"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
    uaPlatform:"Windows", uaFullVersion:"124.0.6367.82",
    uaBrands:[{brand:"Chromium",version:"124"},{brand:"Google Chrome",version:"124"},{brand:"Not-A.Brand",version:"99"}],
    architecture:"x86", bitness:"64", platformVersion:"10.0.0",
    screen:{width:1920,height:1080,colorDepth:24,pixelRatio:1},
    webglVendor:"Intel Inc.", webglRenderer:"Intel(R) UHD Graphics 620",
    webglVendorBasic:"Intel", webglRendererBasic:"Intel(R) UHD Graphics 620",
    fonts:["Arial","Calibri","Courier New","Georgia","Segoe UI","Tahoma","Verdana"],
    speechLang:"uk-UA", connection:{type:"wifi",downlink:10,rtt:40}, battery:{charging:false,level:0.58}
  },

  "EE": {
    name:"Estonia", flag:"🇪🇪", timezone:"Europe/Tallinn", tzOffset:-180,
    languages:["et-EE","et","en","ru"], locale:"et-EE",
    platform:"Win32", vendor:"Google Inc.", productSub:"20030107",
    doNotTrack:"1", hardwareConcurrency:8, deviceMemory:8, maxTouchPoints:0,
    userAgent:"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
    uaPlatform:"Windows", uaFullVersion:"124.0.6367.82",
    uaBrands:[{brand:"Chromium",version:"124"},{brand:"Google Chrome",version:"124"},{brand:"Not-A.Brand",version:"99"}],
    architecture:"x86", bitness:"64", platformVersion:"10.0.0",
    screen:{width:1920,height:1080,colorDepth:24,pixelRatio:1},
    webglVendor:"Intel Inc.", webglRenderer:"Intel(R) UHD Graphics 620",
    webglVendorBasic:"Intel", webglRendererBasic:"Intel(R) UHD Graphics 620",
    fonts:["Arial","Calibri","Courier New","Georgia","Segoe UI","Tahoma","Verdana"],
    speechLang:"et-EE", connection:{type:"wifi",downlink:20,rtt:12}, battery:{charging:false,level:0.76}
  },

  "LV": {
    name:"Latvia", flag:"🇱🇻", timezone:"Europe/Riga", tzOffset:-180,
    languages:["lv-LV","lv","en","ru"], locale:"lv-LV",
    platform:"Win32", vendor:"Google Inc.", productSub:"20030107",
    doNotTrack:"1", hardwareConcurrency:8, deviceMemory:8, maxTouchPoints:0,
    userAgent:"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
    uaPlatform:"Windows", uaFullVersion:"124.0.6367.82",
    uaBrands:[{brand:"Chromium",version:"124"},{brand:"Google Chrome",version:"124"},{brand:"Not-A.Brand",version:"99"}],
    architecture:"x86", bitness:"64", platformVersion:"10.0.0",
    screen:{width:1920,height:1080,colorDepth:24,pixelRatio:1},
    webglVendor:"Intel Inc.", webglRenderer:"Intel(R) UHD Graphics 620",
    webglVendorBasic:"Intel", webglRendererBasic:"Intel(R) UHD Graphics 620",
    fonts:["Arial","Calibri","Courier New","Georgia","Segoe UI","Tahoma","Verdana"],
    speechLang:"lv-LV", connection:{type:"wifi",downlink:15,rtt:14}, battery:{charging:false,level:0.71}
  },

  "LT": {
    name:"Lithuania", flag:"🇱🇹", timezone:"Europe/Vilnius", tzOffset:-180,
    languages:["lt-LT","lt","en","ru"], locale:"lt-LT",
    platform:"Win32", vendor:"Google Inc.", productSub:"20030107",
    doNotTrack:"1", hardwareConcurrency:8, deviceMemory:8, maxTouchPoints:0,
    userAgent:"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
    uaPlatform:"Windows", uaFullVersion:"124.0.6367.82",
    uaBrands:[{brand:"Chromium",version:"124"},{brand:"Google Chrome",version:"124"},{brand:"Not-A.Brand",version:"99"}],
    architecture:"x86", bitness:"64", platformVersion:"10.0.0",
    screen:{width:1920,height:1080,colorDepth:24,pixelRatio:1},
    webglVendor:"Intel Inc.", webglRenderer:"Intel(R) UHD Graphics 620",
    webglVendorBasic:"Intel", webglRendererBasic:"Intel(R) UHD Graphics 620",
    fonts:["Arial","Calibri","Courier New","Georgia","Segoe UI","Tahoma","Verdana"],
    speechLang:"lt-LT", connection:{type:"wifi",downlink:15,rtt:15}, battery:{charging:false,level:0.69}
  },

  // ══════════════════════════════════════════════════
  // RUSSIA
  // ══════════════════════════════════════════════════

  "RU": {
    name:"Russia", flag:"🇷🇺", timezone:"Europe/Moscow", tzOffset:-180,
    languages:["ru-RU","ru","en"], locale:"ru-RU",
    platform:"Win32", vendor:"Google Inc.", productSub:"20030107",
    doNotTrack:null, hardwareConcurrency:8, deviceMemory:8, maxTouchPoints:0,
    userAgent:"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
    uaPlatform:"Windows", uaFullVersion:"124.0.6367.82",
    uaBrands:[{brand:"Chromium",version:"124"},{brand:"Google Chrome",version:"124"},{brand:"Not-A.Brand",version:"99"}],
    architecture:"x86", bitness:"64", platformVersion:"10.0.0",
    screen:{width:1920,height:1080,colorDepth:24,pixelRatio:1},
    webglVendor:"Intel Inc.", webglRenderer:"Intel(R) UHD Graphics 620",
    webglVendorBasic:"Intel", webglRendererBasic:"Intel(R) UHD Graphics 620",
    fonts:["Arial","Calibri","Courier New","Georgia","Segoe UI","Tahoma","Times New Roman","Verdana"],
    speechLang:"ru-RU", connection:{type:"wifi",downlink:10,rtt:45}, battery:{charging:false,level:0.62}
  },

  // ══════════════════════════════════════════════════
  // NORTH AMERICA
  // ══════════════════════════════════════════════════

  "US": {
    name:"United States", flag:"🇺🇸", timezone:"America/New_York", tzOffset:240,
    languages:["en-US","en"], locale:"en-US",
    platform:"Win32", vendor:"Google Inc.", productSub:"20030107",
    doNotTrack:null, hardwareConcurrency:8, deviceMemory:8, maxTouchPoints:0,
    userAgent:"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
    uaPlatform:"Windows", uaFullVersion:"124.0.6367.82",
    uaBrands:[{brand:"Chromium",version:"124"},{brand:"Google Chrome",version:"124"},{brand:"Not-A.Brand",version:"99"}],
    architecture:"x86", bitness:"64", platformVersion:"10.0.0",
    screen:{width:1920,height:1080,colorDepth:24,pixelRatio:1},
    webglVendor:"Google Inc. (NVIDIA)", webglRenderer:"ANGLE (NVIDIA, NVIDIA GeForce GTX 1650 Direct3D11 vs_5_0 ps_5_0)",
    webglVendorBasic:"NVIDIA", webglRendererBasic:"GeForce GTX 1650",
    fonts:["Arial","Arial Black","Calibri","Cambria","Comic Sans MS","Courier New","Georgia","Impact","Segoe UI","Tahoma","Times New Roman","Trebuchet MS","Verdana","Helvetica"],
    speechLang:"en-US", connection:{type:"wifi",downlink:10,rtt:30}, battery:{charging:true,level:0.85}
  },

  "CA": {
    name:"Canada", flag:"🇨🇦", timezone:"America/Toronto", tzOffset:240,
    languages:["en-CA","en","fr-CA","fr"], locale:"en-CA",
    platform:"Win32", vendor:"Google Inc.", productSub:"20030107",
    doNotTrack:null, hardwareConcurrency:8, deviceMemory:8, maxTouchPoints:0,
    userAgent:"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
    uaPlatform:"Windows", uaFullVersion:"124.0.6367.82",
    uaBrands:[{brand:"Chromium",version:"124"},{brand:"Google Chrome",version:"124"},{brand:"Not-A.Brand",version:"99"}],
    architecture:"x86", bitness:"64", platformVersion:"10.0.0",
    screen:{width:1920,height:1080,colorDepth:24,pixelRatio:1},
    webglVendor:"Google Inc. (AMD)", webglRenderer:"ANGLE (AMD, AMD Radeon RX 580 Direct3D11 vs_5_0 ps_5_0)",
    webglVendorBasic:"AMD", webglRendererBasic:"AMD Radeon RX 580",
    fonts:["Arial","Calibri","Cambria","Courier New","Georgia","Segoe UI","Tahoma","Times New Roman","Verdana"],
    speechLang:"en-CA", connection:{type:"wifi",downlink:10,rtt:25}, battery:{charging:false,level:0.68}
  },

  // ══════════════════════════════════════════════════
  // EAST ASIA
  // ══════════════════════════════════════════════════

  "JP": {
    name:"Japan", flag:"🇯🇵", timezone:"Asia/Tokyo", tzOffset:-540,
    languages:["ja-JP","ja","en-US","en"], locale:"ja-JP",
    platform:"Win32", vendor:"Google Inc.", productSub:"20030107",
    doNotTrack:null, hardwareConcurrency:8, deviceMemory:8, maxTouchPoints:0,
    userAgent:"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
    uaPlatform:"Windows", uaFullVersion:"124.0.6367.82",
    uaBrands:[{brand:"Chromium",version:"124"},{brand:"Google Chrome",version:"124"},{brand:"Not-A.Brand",version:"99"}],
    architecture:"x86", bitness:"64", platformVersion:"10.0.0",
    screen:{width:1920,height:1080,colorDepth:24,pixelRatio:1},
    webglVendor:"Intel Inc.", webglRenderer:"Intel(R) UHD Graphics 630",
    webglVendorBasic:"Intel", webglRendererBasic:"Intel(R) UHD Graphics 630",
    fonts:["Arial","Courier New","Georgia","MS Gothic","MS Mincho","Meiryo","Tahoma","Times New Roman","Verdana","Yu Gothic","Yu Mincho"],
    speechLang:"ja-JP", connection:{type:"wifi",downlink:30,rtt:5}, battery:{charging:true,level:0.95}
  },

  "KR": {
    name:"South Korea", flag:"🇰🇷", timezone:"Asia/Seoul", tzOffset:-540,
    languages:["ko-KR","ko","en-US","en"], locale:"ko-KR",
    platform:"Win32", vendor:"Google Inc.", productSub:"20030107",
    doNotTrack:null, hardwareConcurrency:8, deviceMemory:8, maxTouchPoints:0,
    userAgent:"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
    uaPlatform:"Windows", uaFullVersion:"124.0.6367.82",
    uaBrands:[{brand:"Chromium",version:"124"},{brand:"Google Chrome",version:"124"},{brand:"Not-A.Brand",version:"99"}],
    architecture:"x86", bitness:"64", platformVersion:"10.0.0",
    screen:{width:1920,height:1080,colorDepth:24,pixelRatio:1},
    webglVendor:"Intel Inc.", webglRenderer:"Intel(R) UHD Graphics 630",
    webglVendorBasic:"Intel", webglRendererBasic:"Intel(R) UHD Graphics 630",
    fonts:["Arial","Batang","Dotum","Gulim","Gungsuh","Courier New","Georgia","Malgun Gothic","Tahoma","Times New Roman","Verdana"],
    speechLang:"ko-KR", connection:{type:"wifi",downlink:50,rtt:4}, battery:{charging:false,level:0.88}
  },

  // ══════════════════════════════════════════════════
  // SOUTH & SOUTHEAST ASIA + OCEANIA
  // ══════════════════════════════════════════════════

  "SG": {
    name:"Singapore", flag:"🇸🇬", timezone:"Asia/Singapore", tzOffset:-480,
    languages:["en-SG","en","zh-SG","zh"], locale:"en-SG",
    platform:"Win32", vendor:"Google Inc.", productSub:"20030107",
    doNotTrack:null, hardwareConcurrency:8, deviceMemory:16, maxTouchPoints:0,
    userAgent:"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
    uaPlatform:"Windows", uaFullVersion:"124.0.6367.82",
    uaBrands:[{brand:"Chromium",version:"124"},{brand:"Google Chrome",version:"124"},{brand:"Not-A.Brand",version:"99"}],
    architecture:"x86", bitness:"64", platformVersion:"10.0.0",
    screen:{width:2560,height:1440,colorDepth:24,pixelRatio:1},
    webglVendor:"Intel Inc.", webglRenderer:"Intel(R) Iris(R) Xe Graphics",
    webglVendorBasic:"Intel", webglRendererBasic:"Intel(R) Iris(R) Xe Graphics",
    fonts:["Arial","Calibri","Courier New","Georgia","Segoe UI","Tahoma","Verdana"],
    speechLang:"en-SG", connection:{type:"wifi",downlink:50,rtt:3}, battery:{charging:false,level:0.80}
  },

  "AU": {
    name:"Australia", flag:"🇦🇺", timezone:"Australia/Sydney", tzOffset:-600,
    languages:["en-AU","en"], locale:"en-AU",
    platform:"Win32", vendor:"Google Inc.", productSub:"20030107",
    doNotTrack:null, hardwareConcurrency:8, deviceMemory:8, maxTouchPoints:0,
    userAgent:"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
    uaPlatform:"Windows", uaFullVersion:"124.0.6367.82",
    uaBrands:[{brand:"Chromium",version:"124"},{brand:"Google Chrome",version:"124"},{brand:"Not-A.Brand",version:"99"}],
    architecture:"x86", bitness:"64", platformVersion:"10.0.0",
    screen:{width:1920,height:1080,colorDepth:24,pixelRatio:1},
    webglVendor:"Google Inc. (AMD)", webglRenderer:"ANGLE (AMD, AMD Radeon RX 580 Direct3D11 vs_5_0 ps_5_0)",
    webglVendorBasic:"AMD", webglRendererBasic:"AMD Radeon RX 580",
    fonts:["Arial","Calibri","Courier New","Georgia","Segoe UI","Tahoma","Verdana"],
    speechLang:"en-AU", connection:{type:"wifi",downlink:15,rtt:20}, battery:{charging:false,level:0.65}
  }

};

// ══════════════════════════════════════════════════
// HEADER RULES
// ══════════════════════════════════════════════════
function buildHeaderRules(profile) {
  if (!profile) return [];
  const rules = [];
  let id = 1;
  const acceptLang = profile.languages.map((l,i) => i===0 ? l : `${l};q=${(1-i*0.1).toFixed(1)}`).join(',');
  const allTypes = ["main_frame","sub_frame","stylesheet","script","image","font","object","xmlhttprequest","ping","media","websocket","other"];
  const mainTypes = ["main_frame","sub_frame","xmlhttprequest","other"];
  const secChUa = profile.uaBrands.map(b=>`"${b.brand}";v="${b.version}"`).join(', ');

  rules.push({ id:id++, priority:1, action:{type:"modifyHeaders",requestHeaders:[{header:"Accept-Language",operation:"set",value:acceptLang}]}, condition:{urlFilter:"*",resourceTypes:allTypes}});
  rules.push({ id:id++, priority:1, action:{type:"modifyHeaders",requestHeaders:[{header:"User-Agent",operation:"set",value:profile.userAgent}]}, condition:{urlFilter:"*",resourceTypes:mainTypes}});
  rules.push({ id:id++, priority:1, action:{type:"modifyHeaders",requestHeaders:[{header:"Sec-CH-UA",operation:"set",value:secChUa},{header:"Sec-CH-UA-Mobile",operation:"set",value:"?0"},{header:"Sec-CH-UA-Platform",operation:"set",value:`"${profile.uaPlatform}"`}]}, condition:{urlFilter:"*",resourceTypes:mainTypes}});
  rules.push({ id:id++, priority:1, action:{type:"modifyHeaders",requestHeaders:[{header:"Accept",operation:"set",value:"text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8"},{header:"Accept-Encoding",operation:"set",value:"gzip, deflate, br, zstd"}]}, condition:{urlFilter:"*",resourceTypes:["main_frame","sub_frame"]}});
  rules.push({ id:id++, priority:1, action:{type:"modifyHeaders",requestHeaders:[{header:"X-Forwarded-For",operation:"remove"},{header:"X-Real-IP",operation:"remove"},{header:"Via",operation:"remove"},{header:"Forwarded",operation:"remove"}]}, condition:{urlFilter:"*",resourceTypes:mainTypes}});
  return rules;
}

// ══════════════════════════════════════════════════
// STATE
// ══════════════════════════════════════════════════
let state = {
  enabled: true,
  detectedCountry: null,
  overrideCountry: null,
  currentIP: null,
  lastIPCheck: null,
  isChecking: false,
  lastError: null
};

function getActiveCountry() { return state.overrideCountry || state.detectedCountry; }
function getActiveProfile() { return COUNTRY_PROFILES[getActiveCountry()] || null; }

// ══════════════════════════════════════════════════
// IP DETECTION — 4 fallback services
// ══════════════════════════════════════════════════
const IP_SERVICES = [
  { url:'https://ip-api.com/json/?fields=status,countryCode,query', parse:(d)=>d.status==='success'?{country:d.countryCode,ip:d.query}:null },
  { url:'https://ipapi.co/json/', parse:(d)=>d.country_code?{country:d.country_code,ip:d.ip}:null },
  { url:'https://ipwho.is/', parse:(d)=>d.success?{country:d.country_code,ip:d.ip}:null },
  { url:'https://freeipapi.com/api/json', parse:(d)=>d.countryCode?{country:d.countryCode,ip:d.ipAddress}:null }
];

async function fetchWithTimeout(url, ms=5000) {
  const ctrl = new AbortController();
  const t = setTimeout(()=>ctrl.abort(), ms);
  try {
    const r = await fetch(url, {signal:ctrl.signal, cache:'no-cache'});
    return await r.json();
  } finally { clearTimeout(t); }
}

async function detectCountryFromIP() {
  if (state.isChecking) return;
  state.isChecking = true;
  state.lastError = null;
  updateBadge();

  let detected = null;
  for (const svc of IP_SERVICES) {
    try {
      const data = await fetchWithTimeout(svc.url);
      detected = svc.parse(data);
      if (detected) { console.log('[GeoShift] IP:', detected.ip, '→', detected.country); break; }
    } catch(e) { console.warn('[GeoShift] Service failed:', svc.url, e.message); }
  }

  if (detected) {
    const prev = state.detectedCountry;
    state.detectedCountry = detected.country;
    state.currentIP = detected.ip;
    state.lastIPCheck = Date.now();
    await chrome.storage.local.set({ geoshift_state: state });
    if (prev !== detected.country) { await applyHeaderRules(getActiveProfile()); notifyAllTabs(); }
  } else {
    state.lastError = 'All IP services failed';
    console.error('[GeoShift] All IP services failed');
  }
  state.isChecking = false;
  updateBadge();
}

// ══════════════════════════════════════════════════
// HEADER RULES
// ══════════════════════════════════════════════════
async function applyHeaderRules(profile) {
  try {
    const existing = await chrome.declarativeNetRequest.getDynamicRules();
    const removeIds = existing.map(r=>r.id);
    const newRules = (state.enabled && profile) ? buildHeaderRules(profile) : [];
    await chrome.declarativeNetRequest.updateDynamicRules({ removeRuleIds: removeIds, addRules: newRules });
  } catch(e) { console.error('[GeoShift] Header rules error:', e); }
}

// ══════════════════════════════════════════════════
// NOTIFY TABS
// ══════════════════════════════════════════════════
async function notifyAllTabs() {
  const tabs = await chrome.tabs.query({ url:['http://*/*','https://*/*'] });
  const profile = getActiveProfile();
  const country = getActiveCountry();
  for (const tab of tabs) {
    chrome.tabs.sendMessage(tab.id, { type:'GEOSHIFT_UPDATE', country, profile, enabled:state.enabled }).catch(()=>{});
  }
}

// ══════════════════════════════════════════════════
// BADGE
// ══════════════════════════════════════════════════
function updateBadge() {
  const country = getActiveCountry();
  const profile = getActiveProfile();
  if (!state.enabled) {
    chrome.action.setBadgeText({text:'OFF'}); chrome.action.setBadgeBackgroundColor({color:'#666666'});
  } else if (state.isChecking) {
    chrome.action.setBadgeText({text:'...'}); chrome.action.setBadgeBackgroundColor({color:'#FF9F43'});
  } else if (profile) {
    chrome.action.setBadgeText({text:country}); chrome.action.setBadgeBackgroundColor({color:'#00C896'});
  } else {
    chrome.action.setBadgeText({text:'?'}); chrome.action.setBadgeBackgroundColor({color:'#FF6B35'});
  }
}

// ══════════════════════════════════════════════════
// MESSAGES
// ══════════════════════════════════════════════════
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === 'GET_STATE') {
    sendResponse({ ...state, activeCountry:getActiveCountry(), profile:getActiveProfile(),
      availableCountries: Object.entries(COUNTRY_PROFILES).map(([code,p])=>({code, name:p.name, flag:p.flag})) });
    return false;
  }
  if (msg.type === 'SET_ENABLED') {
    state.enabled = msg.enabled;
    chrome.storage.local.set({geoshift_state:state});
    applyHeaderRules(getActiveProfile()); notifyAllTabs(); updateBadge();
    sendResponse({ok:true}); return false;
  }
  if (msg.type === 'SET_OVERRIDE') {
    state.overrideCountry = msg.country || null;
    chrome.storage.local.set({geoshift_state:state});
    applyHeaderRules(getActiveProfile()); notifyAllTabs(); updateBadge();
    sendResponse({ok:true}); return false;
  }
  if (msg.type === 'REFRESH_IP') {
    detectCountryFromIP().then(()=>{ sendResponse({country:state.detectedCountry, ip:state.currentIP, error:state.lastError}); });
    return true;
  }
  if (msg.type === 'GET_PROFILE') {
    const c = msg.country || getActiveCountry();
    sendResponse({country:c, profile:COUNTRY_PROFILES[c]||null}); return false;
  }
});

// ══════════════════════════════════════════════════
// TAB UPDATES
// ══════════════════════════════════════════════════
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status !== 'loading' || !tab.url?.startsWith('http') || !state.enabled) return;
  const profile = getActiveProfile();
  if (!profile) return;
  chrome.tabs.sendMessage(tabId, { type:'GEOSHIFT_UPDATE', country:getActiveCountry(), profile, enabled:state.enabled }).catch(()=>{});
});

// ══════════════════════════════════════════════════
// ALARMS & INIT
// ══════════════════════════════════════════════════
chrome.alarms.create('ip_check', {periodInMinutes:3});
chrome.alarms.onAlarm.addListener(a => { if (a.name==='ip_check') detectCountryFromIP(); });

async function init() {
  const stored = await chrome.storage.local.get('geoshift_state');
  if (stored.geoshift_state) state = {...state, ...stored.geoshift_state, isChecking:false};
  updateBadge();
  await new Promise(r=>setTimeout(r,800));
  await detectCountryFromIP();
  await applyHeaderRules(getActiveProfile());
}

init();
