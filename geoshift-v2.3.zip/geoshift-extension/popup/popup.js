// popup/popup.js — GeoShift v2.2

const PROTECTIONS = [
  'Timezone','Language','HTTP Headers','Client Hints','User-Agent',
  'WebGL','Canvas','Audio','WebRTC','Screen','Hardware','Fonts',
  'Media Devices','Sensors','Storage','Battery','Connection',
  'Anti-Bot','Permissions','Locale/Intl','Codecs','Speech'
];

let state = null;
let dropdownOpen = false;
let searchQuery = '';

const $ = id => document.getElementById(id);

// ══════════════════════════════════════════════════
// Load & Render
// ══════════════════════════════════════════════════
function loadState() {
  chrome.runtime.sendMessage({ type:'GET_STATE' }, (response) => {
    if (chrome.runtime.lastError || !response) { showError('Extension not responding'); return; }
    state = response;
    renderUI();
  });
}

function renderUI() {
  if (!state) return;

  // Toggle
  $('main-toggle').checked = state.enabled;
  $('toggle-label').textContent = state.enabled ? 'Active' : 'Paused';

  const profile = state.profile;
  const on = state.enabled && !!profile;

  // IP & Status
  if (state.isChecking) {
    $('status-ip').textContent = 'Detecting…';
    $('status-dot').className = 'dot warning';
    $('status-text').textContent = 'Checking VPN IP…';
  } else if (state.lastError && !state.currentIP) {
    $('status-ip').textContent = 'Failed';
    $('status-dot').className = 'dot error';
    $('status-text').textContent = 'Auto-detect failed — select manually';
  } else if (state.currentIP) {
    $('status-ip').textContent = state.currentIP;
    if (!state.enabled) {
      $('status-dot').className = 'dot error';
      $('status-text').textContent = 'Protection paused';
    } else if (profile) {
      $('status-dot').className = 'dot active';
      $('status-text').textContent = `Synced → ${profile.name}`;
    } else {
      $('status-dot').className = 'dot warning';
      $('status-text').textContent = `${state.detectedCountry || '?'} — no profile, select manually`;
    }
  } else {
    $('status-ip').textContent = '—';
    $('status-dot').className = 'dot warning';
    $('status-text').textContent = 'Connect VPN then press ↻';
  }

  // Signal count
  $('signal-count').textContent = on
    ? `${PROTECTIONS.length} signals protected`
    : 'Protection off';

  // Tags
  const tagsEl = $('protection-tags');
  tagsEl.innerHTML = '';
  PROTECTIONS.forEach(label => {
    const tag = document.createElement('span');
    tag.className = `tag ${on ? 'on' : 'off'}`;
    tag.textContent = on ? `✓ ${label}` : `✗ ${label}`;
    tagsEl.appendChild(tag);
  });

  // Country display
  if (state.overrideCountry && profile) {
    $('country-flag').textContent   = profile.flag;
    $('country-name').textContent   = profile.name;
    $('country-detail').textContent = `Manual · ${profile.timezone}`;
  } else if (profile) {
    $('country-flag').textContent   = profile.flag;
    $('country-name').textContent   = `${profile.name} (Auto)`;
    $('country-detail').textContent = `VPN detected · ${profile.timezone}`;
  } else {
    $('country-flag').textContent   = '🌐';
    $('country-name').textContent   = state.detectedCountry ? `${state.detectedCountry} — No profile` : 'Unknown';
    $('country-detail').textContent = 'Select country manually ↓';
  }

  if (dropdownOpen) buildDropdown();
}

// ══════════════════════════════════════════════════
// Dropdown with Search
// ══════════════════════════════════════════════════
function buildDropdown() {
  if (!state) return;
  const dd = $('country-list');
  dd.innerHTML = '';

  const query = searchQuery.toLowerCase();
  const countries = (state.availableCountries || []).filter(c =>
    !query || c.name.toLowerCase().includes(query) || c.code.toLowerCase().includes(query)
  );

  // Auto option (only show when no search)
  if (!query) {
    const autoOpt = document.createElement('div');
    autoOpt.className = `country-option ${!state.overrideCountry ? 'selected' : ''}`;
    autoOpt.innerHTML = `<span class="opt-flag">🔄</span><div class="opt-info"><div class="opt-name">Auto (from VPN)</div></div>${!state.overrideCountry ? '<span class="opt-check">✓</span>' : ''}`;
    autoOpt.addEventListener('click', () => setOverride(null));
    dd.appendChild(autoOpt);
  }

  if (countries.length === 0) {
    dd.innerHTML += `<div style="padding:10px 14px;color:#7b82a0;font-size:12px">No countries found</div>`;
    return;
  }

  countries.forEach(({ code, name, flag }) => {
    const isSelected = state.overrideCountry === code;
    const opt = document.createElement('div');
    opt.className = `country-option ${isSelected ? 'selected' : ''}`;
    opt.innerHTML = `
      <span class="opt-flag">${flag}</span>
      <div class="opt-info">
        <div class="opt-name">${name}</div>
        <div class="opt-code">${code}</div>
      </div>
      ${isSelected ? '<span class="opt-check">✓</span>' : ''}
    `;
    opt.addEventListener('click', () => setOverride(code));
    dd.appendChild(opt);
  });
}

// ══════════════════════════════════════════════════
// Actions
// ══════════════════════════════════════════════════
function setOverride(country) {
  chrome.runtime.sendMessage({ type:'SET_OVERRIDE', country }, () => {
    loadState();
    closeDropdown();
  });
}

function openDropdown() {
  dropdownOpen = true;
  searchQuery = '';
  $('country-search').value = '';
  $('country-dropdown').classList.add('open');
  $('country-change-btn').textContent = 'Close';
  buildDropdown();
  setTimeout(() => $('country-search').focus(), 50);
}

function closeDropdown() {
  dropdownOpen = false;
  searchQuery = '';
  $('country-dropdown').classList.remove('open');
  $('country-change-btn').textContent = 'Change';
}

function showError(msg) {
  const dot = $('status-dot');
  const txt = $('status-text');
  if (dot) dot.className = 'dot error';
  if (txt) txt.textContent = msg;
}

// ══════════════════════════════════════════════════
// Events
// ══════════════════════════════════════════════════
$('main-toggle').addEventListener('change', () => {
  chrome.runtime.sendMessage({ type:'SET_ENABLED', enabled:$('main-toggle').checked }, loadState);
});

$('refresh-btn').addEventListener('click', () => {
  const btn = $('refresh-btn');
  btn.classList.add('spinning');
  btn.disabled = true;
  chrome.runtime.sendMessage({ type:'REFRESH_IP' }, () => {
    btn.classList.remove('spinning');
    btn.disabled = false;
    loadState();
  });
});

$('country-change-btn').addEventListener('click', () => {
  dropdownOpen ? closeDropdown() : openDropdown();
});

$('country-search').addEventListener('input', (e) => {
  searchQuery = e.target.value;
  buildDropdown();
});

$('test-btn').addEventListener('click', () => {
  chrome.tabs.create({ url:'https://browserleaks.com/webrtc' });
});

document.addEventListener('click', e => {
  const wrap = $('country-selector-wrap');
  if (wrap && !wrap.contains(e.target)) closeDropdown();
});

loadState();
