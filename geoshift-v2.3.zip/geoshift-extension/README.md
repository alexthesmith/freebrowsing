# GeoShift — Browser Fingerprint Sync Extension

## 🚀 نصب (Developer Mode)

### Chrome / Edge / Brave
1. آدرس `chrome://extensions` رو باز کن
2. **Developer mode** رو از گوشه بالا راست فعال کن
3. روی **Load unpacked** کلیک کن
4. پوشه `geoshift-extension` رو انتخاب کن
5. تمام! آیکون GeoShift در toolbar ظاهر میشه

### Firefox
1. آدرس `about:debugging#/runtime/this-firefox` رو باز کن
2. روی **Load Temporary Add-on** کلیک کن
3. فایل `manifest.json` رو از داخل پوشه انتخاب کن

---

## ✅ چی Spoof میشه (مرحله ۱)

| لایه | سیگنال | وضعیت |
|------|---------|--------|
| 🌍 Locale | `navigator.language` و `navigator.languages` | ✅ |
| 🕐 Timezone | `Intl.DateTimeFormat` و `getTimezoneOffset` | ✅ |
| 🖥️ Hardware | `hardwareConcurrency`، `deviceMemory`، `platform` | ✅ |
| 📺 Screen | `width`، `height`، `colorDepth`، `pixelRatio` | ✅ |
| 🎨 Canvas | Noise injection در `toDataURL` و `getImageData` | ✅ |
| 🔷 WebGL | `UNMASKED_VENDOR` و `UNMASKED_RENDERER` | ✅ |
| 🔊 Audio | Noise در `AnalyserNode` | ✅ |
| 📡 WebRTC | جلوگیری از IP leak | ✅ |
| 🔌 Connection | `effectiveType`، `downlink`، `rtt` | ✅ |
| 🔋 Battery | `level`، `charging` | ✅ |
| 🗣️ Speech | Voices locale filter | ✅ |
| 🔢 Intl | `NumberFormat`، `Collator` locale | ✅ |

---

## 🌍 کشورهای پشتیبانی شده (مرحله ۱)

| کد | کشور |
|----|------|
| DE | آلمان |
| US | آمریکا |
| GB | انگلیس |
| FR | فرانسه |
| NL | هلند |
| SE | سوئد |
| CA | کانادا |
| JP | ژاپن |
| SG | سنگاپور |
| AU | استرالیا |

---

## 🧪 تست

بعد از نصب، روی **Test Fingerprint** در popup کلیک کن تا به coveryourtracks.eff.org بری.
همچنین میتونی از این سایت‌ها تست کنی:
- https://browserleaks.com
- https://amiunique.org
- https://www.whatismybrowser.com

---

## 📁 ساختار پروژه

```
geoshift-extension/
├── manifest.json          # تنظیمات اکستنشن
├── background/
│   └── service-worker.js  # مغز اصلی - تشخیص IP
├── content/
│   ├── injector.js        # inject در هر صفحه
│   └── spoofer.js         # override همه API ها
├── popup/
│   ├── popup.html         # رابط کاربری
│   └── popup.js           # منطق popup
├── data/
│   └── countries.js       # پروفایل ۱۰ کشور
└── icons/
    ├── icon16.png
    ├── icon48.png
    └── icon128.png
```

---

## 🗺️ مرحله بعدی (مرحله ۲)

- [ ] اضافه کردن ۵۰ کشور دیگه به دیتابیس
- [ ] Font list normalization پیشرفته
- [ ] UserAgent کامل sync
- [ ] Keyboard layout spoof
- [ ] پشتیبانی Firefox کامل
- [ ] تست خودکار روی سایت‌های مختلف
