// content/spoofer.js — GeoShift v2.0
// پوشش ~90 سیگنال fingerprinting

(function (profile) {
  if (!profile) return;

  // seed ثابت برای این session — consistent ولی منحصربه‌فرد
  const SESSION_SEED = (function() {
    const s = Math.floor(Math.random() * 0xFFFFFF);
    return s;
  })();

  function seededRandom(index) {
    const x = Math.sin(SESSION_SEED + index) * 10000;
    return x - Math.floor(x);
  }

  // ══════════════════════════════════════════════════
  // BLOCK 1 — TIMEZONE & DATE
  // ══════════════════════════════════════════════════
  try {
    const OrigDTF = Intl.DateTimeFormat;
    function PatchedDTF(locales, options) {
      if (!options) options = {};
      if (!options.timeZone) options.timeZone = profile.timezone;
      const instance = new OrigDTF(locales, options);
      Object.defineProperty(instance, 'resolvedOptions', {
        value: function() {
          return { ...OrigDTF.prototype.resolvedOptions.call(this), timeZone: profile.timezone };
        }
      });
      return instance;
    }
    PatchedDTF.prototype = OrigDTF.prototype;
    PatchedDTF.supportedLocalesOf = OrigDTF.supportedLocalesOf;
    Intl.DateTimeFormat = PatchedDTF;

    const offset = profile.tzOffset ?? 0;
    Date.prototype.getTimezoneOffset = function() { return offset; };

    // toLocaleDateString / toLocaleTimeString / toLocaleString
    ['toLocaleDateString','toLocaleTimeString','toLocaleString'].forEach(fn => {
      const orig = Date.prototype[fn];
      Date.prototype[fn] = function(locales, options) {
        return orig.call(this, profile.locale, { timeZone: profile.timezone, ...options });
      };
    });
  } catch(e) {}

  // ══════════════════════════════════════════════════
  // BLOCK 2 — NAVIGATOR: LANGUAGE & LOCALE
  // ══════════════════════════════════════════════════
  try {
    const navProps = {
      language:     { get: () => profile.languages[0] },
      languages:    { get: () => Object.freeze([...profile.languages]) },
      platform:     { get: () => profile.platform },
      vendor:       { get: () => profile.vendor },
      productSub:   { get: () => profile.productSub },
      doNotTrack:   { get: () => profile.doNotTrack },
      globalPrivacyControl: { get: () => profile.globalPrivacyControl },
      hardwareConcurrency:  { get: () => profile.hardwareConcurrency },
      deviceMemory:         { get: () => profile.deviceMemory },
      maxTouchPoints:       { get: () => profile.maxTouchPoints },
      cookieEnabled:        { get: () => true },
      onLine:               { get: () => true },
      pdfViewerEnabled:     { get: () => true },
    };
    for (const [key, desc] of Object.entries(navProps)) {
      try {
        Object.defineProperty(navigator, key, { ...desc, configurable: true });
      } catch(_) {}
    }
  } catch(e) {}

  // ══════════════════════════════════════════════════
  // BLOCK 3 — WEBDRIVER & AUTOMATION DETECTION
  // ══════════════════════════════════════════════════
  try {
    // webdriver flag
    Object.defineProperty(navigator, 'webdriver', { get: () => false, configurable: true });

    // حذف chrome.runtime از دید صفحه (headless indicator)
    // فقط chrome object رو normalize می‌کنیم، حذف نمی‌کنیم
    if (window.chrome) {
      if (!window.chrome.runtime) {
        window.chrome.runtime = {};
      }
    } else {
      // اگه chrome وجود نداره (headless)، یه شبیه‌سازی ساده
      Object.defineProperty(window, 'chrome', {
        get: () => ({ runtime: {}, loadTimes: function(){}, csi: function(){} }),
        configurable: true
      });
    }

    // حذف Notification.permission اتوماتیک
    if (window.Notification) {
      try {
        Object.defineProperty(Notification, 'permission', {
          get: () => 'default',
          configurable: true
        });
      } catch(_) {}
    }

    // جلوگیری از تشخیص automation از طریق plugins
    const pluginData = [
      { name: 'Chrome PDF Plugin', filename: 'internal-pdf-viewer', description: 'Portable Document Format' },
      { name: 'Chrome PDF Viewer', filename: 'mhjfbmdgcfjbbpaeojofohoefgiehjai', description: '' },
      { name: 'Native Client', filename: 'internal-nacl-plugin', description: '' }
    ];
    const pluginArray = Object.create(PluginArray.prototype);
    pluginData.forEach((p, i) => {
      const plugin = Object.create(Plugin.prototype);
      Object.defineProperty(plugin, 'name', { get: () => p.name });
      Object.defineProperty(plugin, 'filename', { get: () => p.filename });
      Object.defineProperty(plugin, 'description', { get: () => p.description });
      Object.defineProperty(plugin, 'length', { get: () => 0 });
      Object.defineProperty(pluginArray, i, { get: () => plugin });
      Object.defineProperty(pluginArray, p.name, { get: () => plugin });
    });
    Object.defineProperty(pluginArray, 'length', { get: () => pluginData.length });
    Object.defineProperty(navigator, 'plugins', { get: () => pluginArray, configurable: true });

    // mimeTypes
    const mimeArray = Object.create(MimeTypeArray.prototype);
    Object.defineProperty(mimeArray, 'length', { get: () => 2 });
    Object.defineProperty(navigator, 'mimeTypes', { get: () => mimeArray, configurable: true });

  } catch(e) {}

  // ══════════════════════════════════════════════════
  // BLOCK 4 — USER AGENT & CLIENT HINTS (Sec-CH-UA)
  // ══════════════════════════════════════════════════
  try {
    // userAgent
    Object.defineProperty(navigator, 'userAgent', {
      get: () => profile.userAgent,
      configurable: true
    });
    Object.defineProperty(navigator, 'appVersion', {
      get: () => profile.userAgent.replace('Mozilla/', ''),
      configurable: true
    });

    // userAgentData (Client Hints API)
    if (navigator.userAgentData !== undefined) {
      const uaData = {
        brands: profile.uaBrands,
        mobile: false,
        platform: profile.uaPlatform,
        getHighEntropyValues: async function(hints) {
          const result = {};
          if (hints.includes('architecture'))    result.architecture = profile.architecture;
          if (hints.includes('bitness'))         result.bitness = profile.bitness;
          if (hints.includes('model'))           result.model = '';
          if (hints.includes('platformVersion')) result.platformVersion = profile.platformVersion;
          if (hints.includes('uaFullVersion'))   result.uaFullVersion = profile.uaFullVersion;
          if (hints.includes('fullVersionList')) result.fullVersionList = profile.uaBrands;
          if (hints.includes('wow64'))           result.wow64 = false;
          if (hints.includes('platform'))        result.platform = profile.uaPlatform;
          if (hints.includes('mobile'))          result.mobile = false;
          return result;
        },
        toJSON: function() {
          return { brands: profile.uaBrands, mobile: false, platform: profile.uaPlatform };
        }
      };
      Object.defineProperty(navigator, 'userAgentData', {
        get: () => uaData,
        configurable: true
      });
    }
  } catch(e) {}

  // ══════════════════════════════════════════════════
  // BLOCK 5 — SCREEN
  // ══════════════════════════════════════════════════
  try {
    const sc = profile.screen;
    const screenDefs = {
      width:       sc.width,
      height:      sc.height,
      availWidth:  sc.width,
      availHeight: sc.height - 48,
      colorDepth:  sc.colorDepth,
      pixelDepth:  sc.colorDepth,
      orientation: {
        type: 'landscape-primary',
        angle: 0,
        addEventListener: () => {},
        removeEventListener: () => {}
      }
    };
    for (const [key, val] of Object.entries(screenDefs)) {
      try {
        Object.defineProperty(screen, key, { get: () => val, configurable: true });
      } catch(_) {}
    }
    Object.defineProperty(window, 'devicePixelRatio', {
      get: () => sc.pixelRatio,
      configurable: true
    });
    // innerWidth/innerHeight — consistent با screen
    Object.defineProperty(window, 'outerWidth',  { get: () => sc.width,  configurable: true });
    Object.defineProperty(window, 'outerHeight', { get: () => sc.height, configurable: true });
  } catch(e) {}

  // ══════════════════════════════════════════════════
  // BLOCK 6 — CANVAS 2D FINGERPRINT
  // ══════════════════════════════════════════════════
  try {
    const origToDataURL    = HTMLCanvasElement.prototype.toDataURL;
    const origToBlob       = HTMLCanvasElement.prototype.toBlob;
    const origGetImageData = CanvasRenderingContext2D.prototype.getImageData;

    function noiseImageData(imageData) {
      const d = imageData.data;
      for (let i = 0; i < d.length; i += 4) {
        const n = Math.floor(seededRandom(i) * 3) - 1; // -1, 0, or 1
        d[i]   = Math.max(0, Math.min(255, d[i]   + n));
        d[i+1] = Math.max(0, Math.min(255, d[i+1] + n));
        d[i+2] = Math.max(0, Math.min(255, d[i+2] + n));
      }
      return imageData;
    }

    HTMLCanvasElement.prototype.toDataURL = function(...args) {
      const ctx = this.getContext('2d');
      if (ctx && this.width > 0 && this.height > 0) {
        const id = origGetImageData.call(ctx, 0, 0, this.width, this.height);
        noiseImageData(id);
        ctx.putImageData(id, 0, 0);
      }
      return origToDataURL.apply(this, args);
    };

    HTMLCanvasElement.prototype.toBlob = function(callback, ...args) {
      const ctx = this.getContext('2d');
      if (ctx && this.width > 0 && this.height > 0) {
        const id = origGetImageData.call(ctx, 0, 0, this.width, this.height);
        noiseImageData(id);
        ctx.putImageData(id, 0, 0);
      }
      return origToBlob.call(this, callback, ...args);
    };

    CanvasRenderingContext2D.prototype.getImageData = function(...args) {
      const id = origGetImageData.apply(this, args);
      return noiseImageData(id);
    };
  } catch(e) {}

  // ══════════════════════════════════════════════════
  // BLOCK 7 — WEBGL
  // ══════════════════════════════════════════════════
  try {
    function patchWebGL(ctx) {
      if (!ctx) return;
      const origGetParameter = ctx.getParameter.bind(ctx.__proto__);

      ctx.__proto__.getParameter = function(param) {
        if (param === 37445) return profile.webglVendor;    // UNMASKED_VENDOR_WEBGL
        if (param === 37446) return profile.webglRenderer;  // UNMASKED_RENDERER_WEBGL
        if (param === 7936)  return profile.webglVendorBasic;  // VENDOR
        if (param === 7937)  return profile.webglRendererBasic; // RENDERER
        if (param === 7938)  return 'WebGL 1.0 (OpenGL ES 2.0 Chromium)'; // VERSION
        if (param === 35724) return 'WebGL GLSL ES 1.0 (OpenGL ES GLSL ES 1.0 Chromium)'; // SHADING_LANGUAGE_VERSION
        return origGetParameter.call(this, param);
      };

      // getSupportedExtensions — normalize
      const origGetExt = ctx.__proto__.getSupportedExtensions;
      ctx.__proto__.getSupportedExtensions = function() {
        const exts = origGetExt.call(this);
        // مرتب‌سازی ثابت تا fingerprint consistent باشه
        return exts ? [...exts].sort() : [];
      };
    }

    const origGetContext = HTMLCanvasElement.prototype.getContext;
    HTMLCanvasElement.prototype.getContext = function(type, ...args) {
      const ctx = origGetContext.call(this, type, ...args);
      if (ctx && (type === 'webgl' || type === 'experimental-webgl' || type === 'webgl2')) {
        patchWebGL(ctx);
      }
      return ctx;
    };
  } catch(e) {}

  // ══════════════════════════════════════════════════
  // BLOCK 8 — AUDIO FINGERPRINT
  // ══════════════════════════════════════════════════
  try {
    // OfflineAudioContext fingerprint
    const origOfflineAC = window.OfflineAudioContext || window.webkitOfflineAudioContext;
    if (origOfflineAC) {
      function PatchedOfflineAC(...args) {
        const ctx = new origOfflineAC(...args);
        const origCreateOscillator = ctx.createOscillator.bind(ctx);
        ctx.createOscillator = function() {
          const osc = origCreateOscillator();
          const origConnect = osc.connect.bind(osc);
          osc.connect = function(dest) {
            // اضافه کردن یه GainNode با noise کوچک
            try {
              const gain = ctx.createGain();
              gain.gain.value = 1 + (seededRandom(42) - 0.5) * 0.0001;
              origConnect(gain);
              gain.connect(dest);
              return gain;
            } catch(_) {
              return origConnect(dest);
            }
          };
          return osc;
        };
        return ctx;
      }
      PatchedOfflineAC.prototype = origOfflineAC.prototype;
      window.OfflineAudioContext = PatchedOfflineAC;
      if (window.webkitOfflineAudioContext) window.webkitOfflineAudioContext = PatchedOfflineAC;
    }

    // AnalyserNode noise
    if (window.AnalyserNode) {
      const fns = ['getFloatFrequencyData','getByteFrequencyData','getFloatTimeDomainData','getByteTimeDomainData'];
      fns.forEach(fn => {
        const orig = AnalyserNode.prototype[fn];
        if (!orig) return;
        AnalyserNode.prototype[fn] = function(array) {
          orig.call(this, array);
          for (let i = 0; i < array.length; i++) {
            array[i] += (seededRandom(i) - 0.5) * 0.0003;
          }
        };
      });
    }

    // AudioContext sampleRate normalize
    if (window.AudioContext) {
      const origAC = AudioContext;
      window.AudioContext = function(...args) {
        const ctx = new origAC(...args);
        Object.defineProperty(ctx, 'sampleRate', { get: () => 44100, configurable: true });
        return ctx;
      };
      window.AudioContext.prototype = origAC.prototype;
    }
  } catch(e) {}

  // ══════════════════════════════════════════════════
  // BLOCK 9 — FONT DETECTION PROTECTION
  // ══════════════════════════════════════════════════
  try {
    // measureText noise
    const origMeasureText = CanvasRenderingContext2D.prototype.measureText;
    CanvasRenderingContext2D.prototype.measureText = function(text) {
      const result = origMeasureText.call(this, text);
      const noise = (seededRandom(text.length) - 0.5) * 0.02;
      const orig_w = result.width;
      Object.defineProperty(result, 'width', {
        get: () => orig_w + noise,
        configurable: true
      });
      return result;
    };

    // document.fonts — فقط نشون بده که فونت‌های رایج وجود دارن
    if (document.fonts && document.fonts.check) {
      const origCheck = document.fonts.check.bind(document.fonts);
      document.fonts.check = function(font, text) {
        // فونت‌های ناشناخته رو false برگردون
        const commonFonts = profile.fonts || [];
        const fontName = font.match(/"([^"]+)"|'([^']+)'|(\S+)/)?.[0]?.replace(/['"]/g,'') || '';
        if (fontName && !commonFonts.includes(fontName)) return false;
        return origCheck(font, text);
      };
    }
  } catch(e) {}

  // ══════════════════════════════════════════════════
  // BLOCK 10 — MEDIA DEVICES
  // ══════════════════════════════════════════════════
  try {
    if (navigator.mediaDevices && navigator.mediaDevices.enumerateDevices) {
      const origEnum = navigator.mediaDevices.enumerateDevices.bind(navigator.mediaDevices);
      navigator.mediaDevices.enumerateDevices = async function() {
        const devices = await origEnum();
        // deviceId و groupId رو mask کن
        return devices.map((d, i) => ({
          deviceId: d.deviceId === 'default' ? 'default' : `device_${SESSION_SEED}_${i}`,
          groupId:  `group_${SESSION_SEED}_${Math.floor(i/2)}`,
          kind:     d.kind,
          label:    d.label || ''
        }));
      };
    }
  } catch(e) {}

  // ══════════════════════════════════════════════════
  // BLOCK 11 — PERMISSIONS API
  // ══════════════════════════════════════════════════
  try {
    if (navigator.permissions && navigator.permissions.query) {
      const origQuery = navigator.permissions.query.bind(navigator.permissions);
      navigator.permissions.query = function(descriptor) {
        // اکثر permissions رو به حالت prompt یا granted برگردون
        const alwaysGranted = ['clipboard-read','clipboard-write'];
        const alwaysPrompt  = ['geolocation','camera','microphone','notifications'];
        if (alwaysGranted.includes(descriptor.name)) {
          return Promise.resolve({ state: 'granted', addEventListener: () => {}, removeEventListener: () => {} });
        }
        if (alwaysPrompt.includes(descriptor.name)) {
          return Promise.resolve({ state: 'prompt', addEventListener: () => {}, removeEventListener: () => {} });
        }
        return origQuery(descriptor);
      };
    }
  } catch(e) {}

  // ══════════════════════════════════════════════════
  // BLOCK 12 — BATTERY API
  // ══════════════════════════════════════════════════
  try {
    if (navigator.getBattery) {
      const bat = profile.battery;
      navigator.getBattery = async function() {
        return {
          charging:        bat.charging,
          chargingTime:    bat.charging ? 3600 : Infinity,
          dischargingTime: bat.charging ? Infinity : 5400,
          level:           bat.level,
          addEventListener:    () => {},
          removeEventListener: () => {},
          dispatchEvent:       () => false
        };
      };
    }
  } catch(e) {}

  // ══════════════════════════════════════════════════
  // BLOCK 13 — NETWORK CONNECTION INFO
  // ══════════════════════════════════════════════════
  try {
    const conn = profile.connection;
    const fakeConn = {
      effectiveType: '4g',
      type:          conn.type,
      downlink:      conn.downlink,
      downlinkMax:   Infinity,
      rtt:           conn.rtt,
      saveData:      false,
      addEventListener:    () => {},
      removeEventListener: () => {},
      dispatchEvent:       () => false
    };
    Object.defineProperty(navigator, 'connection',       { get: () => fakeConn, configurable: true });
    Object.defineProperty(navigator, 'mozConnection',    { get: () => fakeConn, configurable: true });
    Object.defineProperty(navigator, 'webkitConnection', { get: () => fakeConn, configurable: true });
  } catch(e) {}

  // ══════════════════════════════════════════════════
  // BLOCK 14 — SPEECH SYNTHESIS
  // ══════════════════════════════════════════════════
  try {
    if (window.speechSynthesis) {
      const origGetVoices = SpeechSynthesis.prototype.getVoices;
      SpeechSynthesis.prototype.getVoices = function() {
        const voices = origGetVoices.call(this);
        const langCode = profile.languages[0].split('-')[0];
        const filtered = voices.filter(v => v.lang.startsWith(langCode));
        return filtered.length > 0 ? filtered : voices.slice(0, 3);
      };
      window.addEventListener('voiceschanged', () => {}, { once: true });
    }
  } catch(e) {}

  // ══════════════════════════════════════════════════
  // BLOCK 15 — INTL / LOCALE APIs
  // ══════════════════════════════════════════════════
  try {
    ['NumberFormat','Collator','PluralRules','ListFormat','RelativeTimeFormat'].forEach(cls => {
      if (!Intl[cls]) return;
      const Orig = Intl[cls];
      Intl[cls] = function(locales, options) {
        return new Orig(profile.locale, options);
      };
      Intl[cls].prototype = Orig.prototype;
      if (Orig.supportedLocalesOf) Intl[cls].supportedLocalesOf = Orig.supportedLocalesOf;
    });

    // Intl.getCanonicalLocales
    if (Intl.getCanonicalLocales) {
      const origGCL = Intl.getCanonicalLocales;
      Intl.getCanonicalLocales = function(locales) {
        if (!locales) return [profile.locale];
        return origGCL(locales);
      };
    }
  } catch(e) {}

  // ══════════════════════════════════════════════════
  // BLOCK 16 — SENSORS (Accelerometer, Gyroscope, etc.)
  // ══════════════════════════════════════════════════
  try {
    // اکثر desktop ها sensor ندارن — false برگردون
    ['Accelerometer','Gyroscope','Magnetometer',
     'AbsoluteOrientationSensor','RelativeOrientationSensor',
     'LinearAccelerationSensor','GravitySensor'].forEach(sensor => {
      if (window[sensor]) {
        window[sensor] = function() {
          throw new DOMException(`Sensor not available`, 'NotAllowedError');
        };
      }
    });

    Object.defineProperty(window, 'DeviceMotionEvent', {
      get: () => undefined, configurable: true
    });
    Object.defineProperty(window, 'DeviceOrientationEvent', {
      get: () => undefined, configurable: true
    });
  } catch(e) {}

  // ══════════════════════════════════════════════════
  // BLOCK 17 — STORAGE FINGERPRINTING
  // ══════════════════════════════════════════════════
  try {
    // StorageManager quota — normalize به مقدار رایج
    if (navigator.storage && navigator.storage.estimate) {
      const origEstimate = navigator.storage.estimate.bind(navigator.storage);
      navigator.storage.estimate = async function() {
        return { quota: 274877906944, usage: Math.floor(seededRandom(1) * 1000000) };
      };
    }
  } catch(e) {}

  // ══════════════════════════════════════════════════
  // BLOCK 18 — WEBRTC LEAK (داخل page context)
  // ══════════════════════════════════════════════════
  try {
    const OrigRTC = window.RTCPeerConnection || window.webkitRTCPeerConnection;
    if (OrigRTC) {
      function PatchedRTC(config, constraints) {
        if (config && config.iceServers) {
          config.iceServers = config.iceServers.filter(s => {
            const urls = Array.isArray(s.urls) ? s.urls : [s.urls || ''];
            return !urls.some(u => typeof u === 'string' && u.startsWith('stun:'));
          });
        }
        const pc = new OrigRTC(config, constraints);
        // IP leak از طریق candidate
        const origAddIceCandidate = pc.addIceCandidate.bind(pc);
        pc.addIceCandidate = function(candidate) {
          if (candidate && candidate.candidate &&
              candidate.candidate.includes('typ host')) {
            return Promise.resolve();
          }
          return origAddIceCandidate(candidate);
        };
        return pc;
      }
      PatchedRTC.prototype = OrigRTC.prototype;
      PatchedRTC.generateCertificate = OrigRTC.generateCertificate;
      window.RTCPeerConnection = PatchedRTC;
      if (window.webkitRTCPeerConnection) window.webkitRTCPeerConnection = PatchedRTC;
    }
  } catch(e) {}

  // ══════════════════════════════════════════════════
  // BLOCK 19 — CONSISTENCY CHECKS
  // اطمینان از سازگاری همه سیگنال‌ها با هم
  // ══════════════════════════════════════════════════
  try {
    // window.name پاک کردن (cross-origin tracking)
    window.name = '';

    // history.length normalize
    try {
      Object.defineProperty(history, 'length', { get: () => 1, configurable: true });
    } catch(_) {}

    // opener null (نشونه‌ای از tab tracking نباشه)
    try {
      Object.defineProperty(window, 'opener', { get: () => null, configurable: true });
    } catch(_) {}

    // Error.stackTraceLimit — consistent
    if (Error.stackTraceLimit !== undefined) {
      Error.stackTraceLimit = 10;
    }
  } catch(e) {}

  // ══════════════════════════════════════════════════
  // BLOCK 20 — MEDIA CODEC SUPPORT
  // ══════════════════════════════════════════════════
  try {
    if (HTMLVideoElement && HTMLVideoElement.prototype.canPlayType) {
      const origCanPlay = HTMLVideoElement.prototype.canPlayType;
      // normalize — همه browser های مدرن این‌ها رو support می‌کنن
      HTMLVideoElement.prototype.canPlayType = function(type) {
        if (type.includes('video/mp4'))  return 'probably';
        if (type.includes('video/webm')) return 'probably';
        if (type.includes('video/ogg'))  return 'maybe';
        return origCanPlay.call(this, type);
      };
    }

    if (HTMLAudioElement && HTMLAudioElement.prototype.canPlayType) {
      const origCanPlayA = HTMLAudioElement.prototype.canPlayType;
      HTMLAudioElement.prototype.canPlayType = function(type) {
        if (type.includes('audio/mpeg'))  return 'probably';
        if (type.includes('audio/ogg'))   return 'probably';
        if (type.includes('audio/wav'))   return 'probably';
        if (type.includes('audio/webm'))  return 'probably';
        return origCanPlayA.call(this, type);
      };
    }
  } catch(e) {}

  // ══════════════════════════════════════════════════
  // BLOCK 21 — MATH & CSS FINGERPRINTING
  // ══════════════════════════════════════════════════
  try {
    // CSS color-gamut و prefers-color-scheme — از طریق matchMedia
    const origMatchMedia = window.matchMedia;
    window.matchMedia = function(query) {
      const result = origMatchMedia ? origMatchMedia.call(window, query) : { matches: false };
      // normalize color-gamut به srgb (رایج‌ترین)
      if (query.includes('color-gamut: p3') || query.includes('color-gamut: rec2020')) {
        return { ...result, matches: false, media: query, addEventListener: ()=>{}, removeEventListener: ()=>{} };
      }
      if (query.includes('color-gamut: srgb')) {
        return { ...result, matches: true, media: query, addEventListener: ()=>{}, removeEventListener: ()=>{} };
      }
      return result;
    };
  } catch(e) {}

  // ══════════════════════════════════════════════════
  // BLOCK 22 — OBJECT TOSTRING PROTECTION
  // جلوگیری از تشخیص override شدن API ها
  // ══════════════════════════════════════════════════
  try {
    const nativeToString = Function.prototype.toString;
    const proxiedFunctions = new WeakSet();

    // برای توابعی که override کردیم، native به نظر برسن
    const makeNative = (fn, name) => {
      if (typeof fn !== 'function') return;
      try {
        const descriptor = {
          value: function toString() {
            return `function ${name || fn.name || ''}() { [native code] }`;
          }
        };
        Object.defineProperty(fn, 'toString', descriptor);
      } catch(_) {}
    };

    // اعمال روی توابع کلیدی که override شدن
    makeNative(navigator.getBattery, 'getBattery');
    makeNative(window.matchMedia, 'matchMedia');
  } catch(e) {}

  console.debug(
    `%c[GeoShift v2] ✅ ${Object.keys({1:0,2:0,3:0,4:0,5:0,6:0,7:0,8:0,9:0,10:0,11:0,12:0,13:0,14:0,15:0,16:0,17:0,18:0,19:0,20:0,21:0,22:0}).length} blocks active → ${profile.languages[0]} / ${profile.timezone}`,
    'color: #00C896; font-weight: bold;'
  );

})(__GEOSHIFT_PROFILE__);
