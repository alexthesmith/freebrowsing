// content/injector.js — GeoShift v2.3
// CRITICAL: runs at document_start
// WebRTC must be blocked SYNCHRONOUSLY before ANY page script runs

(function() {
  'use strict';

  // ══════════════════════════════════════════════════
  // STEP 1: Block WebRTC IMMEDIATELY — inline, synchronous
  // No fetch, no async — inject directly as inline script
  // ══════════════════════════════════════════════════
  const webrtcBlockCode = `(function() {
    'use strict';

    var _rtc = window.RTCPeerConnection
             || window.webkitRTCPeerConnection
             || window.mozRTCPeerConnection;

    if (!_rtc) return;

    function SafeRTC(config, constraints) {
      // Strip ALL ice servers — no STUN, no TURN
      var safeConfig = {
        iceServers: [],
        iceTransportPolicy: 'relay'
      };
      // Keep other options but override ice
      if (config) {
        safeConfig = Object.assign({}, config, {
          iceServers: [],
          iceTransportPolicy: 'relay'
        });
      }

      var pc = new _rtc(safeConfig, constraints);

      // Block host & srflx candidates (they reveal real IP)
      var _addEventL = pc.addEventListener.bind(pc);
      pc.addEventListener = function(type, fn, opts) {
        if (type === 'icecandidate' && fn) {
          return _addEventL(type, function(e) {
            if (e && e.candidate && e.candidate.candidate) {
              var c = e.candidate.candidate;
              if (c.indexOf('typ host') !== -1 || c.indexOf('typ srflx') !== -1) {
                return; // drop it
              }
            }
            fn.call(this, e);
          }, opts);
        }
        return _addEventL(type, fn, opts);
      };

      // Also intercept onicecandidate setter
      var _oic = null;
      Object.defineProperty(pc, 'onicecandidate', {
        get: function() { return _oic; },
        set: function(fn) {
          _oic = fn;
          if (!fn) return;
          _addEventL('icecandidate', function(e) {
            if (e && e.candidate && e.candidate.candidate) {
              var c = e.candidate.candidate;
              if (c.indexOf('typ host') !== -1 || c.indexOf('typ srflx') !== -1) {
                return;
              }
            }
            fn.call(pc, e);
          });
        },
        configurable: true
      });

      return pc;
    }

    // Copy static methods
    SafeRTC.prototype = _rtc.prototype;
    if (_rtc.generateCertificate) SafeRTC.generateCertificate = _rtc.generateCertificate.bind(_rtc);

    // Override all variants
    window.RTCPeerConnection = SafeRTC;
    window.webkitRTCPeerConnection = SafeRTC;
    window.mozRTCPeerConnection = SafeRTC;

    // Also block via Object.defineProperty so pages can't restore it
    ['RTCPeerConnection','webkitRTCPeerConnection','mozRTCPeerConnection'].forEach(function(name) {
      try {
        Object.defineProperty(window, name, {
          get: function() { return SafeRTC; },
          set: function() {}, // ignore attempts to restore
          configurable: false
        });
      } catch(e) {}
    });

    // Block getUserMedia from being used to trigger IP leak
    if (navigator.mediaDevices) {
      var _gum = navigator.mediaDevices.getUserMedia.bind(navigator.mediaDevices);
      Object.defineProperty(navigator.mediaDevices, 'getUserMedia', {
        value: function(constraints) {
          // Allow but WebRTC is already patched so IP won't leak
          return _gum(constraints);
        },
        configurable: true
      });
    }

    console.debug('[GeoShift] WebRTC blocked ✅');
  })();`;

  // Inject WebRTC block as FIRST script — before anything else
  var s = document.createElement('script');
  s.id = '__geoshift_webrtc__';
  s.textContent = webrtcBlockCode;

  var target = document.head || document.documentElement;
  if (target && target.firstChild) {
    target.insertBefore(s, target.firstChild);
  } else if (target) {
    target.appendChild(s);
  } else {
    // Absolute fallback — document not ready yet
    document.addEventListener('DOMContentLoaded', function() {
      (document.head || document.documentElement).insertBefore(s, null);
    }, { once: true });
  }

  // ══════════════════════════════════════════════════
  // STEP 2: Load full spoofer with profile (async is ok here)
  // ══════════════════════════════════════════════════
  var currentProfile = null;
  var isEnabled = true;

  function injectSpoofer(profile) {
    if (!profile || !isEnabled) return;

    var existing = document.getElementById('__geoshift_spoofer__');
    if (existing) existing.remove();

    var url = chrome.runtime.getURL('content/spoofer.js');
    fetch(url)
      .then(function(r) { return r.text(); })
      .then(function(code) {
        var injected = code.replace('__GEOSHIFT_PROFILE__', JSON.stringify(profile));
        var script = document.createElement('script');
        script.id = '__geoshift_spoofer__';
        script.textContent = injected;
        var t = document.head || document.documentElement;
        if (t) t.insertBefore(script, t.firstChild);
      })
      .catch(function(e) { console.error('[GeoShift] spoofer load failed:', e); });
  }

  // Message listener
  chrome.runtime.onMessage.addListener(function(msg, sender, sendResponse) {
    if (msg.type === 'GEOSHIFT_UPDATE') {
      isEnabled = msg.enabled;
      currentProfile = msg.profile;
      if (isEnabled && currentProfile) injectSpoofer(currentProfile);
      sendResponse({ ok: true });
    }
    return false;
  });

  // Get profile from background
  chrome.runtime.sendMessage({ type: 'GET_STATE' }, function(response) {
    if (chrome.runtime.lastError || !response) return;
    isEnabled = response.enabled;
    currentProfile = response.profile;
    if (isEnabled && currentProfile) injectSpoofer(currentProfile);
  });

})();
